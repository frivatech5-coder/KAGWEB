import React from 'react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface ScriptureInterludeProps {
  settings: ChurchSettings;
}

export const ScriptureInterlude: React.FC<ScriptureInterludeProps> = ({ settings }) => {
  const scripture = settings.scripture || {
    label: 'Sacred Scripture Meditation · The Heart of Emmanuel',
    quote: 'And they shall call His name Emmanuel — which being interpreted is, God with us.',
    citation: 'Matthew 1:23 · The Divine Mandate of Witima Sanctuary',
    pillar1Title: 'The Assemblies of God Faith',
    pillar1Desc: 'We proclaim the full Gospel: salvation through Christ alone, the baptism and power of the Holy Spirit, divine healing, and the blessed hope of His imminent return.',
    pillar2Title: 'Highland Calling · Nyeri County',
    pillar2Desc: 'Placed in Witima, Othaya, as an unceasing light of holiness, prayer, generational transformation, and Christlike compassion across Central Kenya.',
  };

  return (
    <section className="relative w-full bg-[#183D32] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 overflow-hidden border-b border-[#F3EFE6]/10">
      {/* Subtle geometric cross watermark */}
      <div className="absolute inset-0 pointer-events-none opacity-5 flex items-center justify-center">
        <div className="w-[1px] h-full bg-[#F3EFE6]" />
        <div className="h-[1px] w-full bg-[#F3EFE6] absolute" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 22 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10"
      >
        {/* Curatorial Header */}
        <div className="inline-flex items-center gap-3 mb-6 sm:mb-8">
          <span className="w-6 sm:w-8 h-px bg-[#B69A62]" />
          <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B69A62] font-semibold">
            {scripture.label}
          </span>
          <span className="w-6 sm:w-8 h-px bg-[#B69A62]" />
        </div>

        {/* Italiana / Cormorant Garamond Typographic Feature */}
        <blockquote className="font-italiana text-2xl sm:text-4xl lg:text-5xl text-[#F3EFE6] leading-tight tracking-wide font-normal max-w-4xl mx-auto">
          “{scripture.quote}”
        </blockquote>

        <div className="mt-6 font-serif italic text-sm sm:text-base text-[#F3EFE6]/75">
          {scripture.citation}
        </div>

        <div className="mt-10 sm:mt-12 max-w-2xl mx-auto pt-6 sm:pt-8 border-t border-[#F3EFE6]/15 grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8 text-left">
          <div>
            <span className="text-[10px] uppercase font-sans tracking-[0.2em] text-[#B69A62] block mb-1.5 font-semibold">
              {scripture.pillar1Title}
            </span>
            <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed">
              {scripture.pillar1Desc}
            </p>
          </div>

          <div>
            <span className="text-[10px] uppercase font-sans tracking-[0.2em] text-[#B69A62] block mb-1.5 font-semibold">
              {scripture.pillar2Title}
            </span>
            <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed">
              {scripture.pillar2Desc}
            </p>
          </div>
        </div>

      </motion.div>
    </section>
  );
};
