import React, { useState } from 'react';
import { Eye, X, ZoomIn } from 'lucide-react';
import { motion } from 'motion/react';
import { defaultGalleryItems } from '../data/defaultChurchData';
import { ChurchSettings, GalleryImageItem } from '../types/church';

interface FellowshipGalleryProps {
  settings: ChurchSettings;
}

export const FellowshipGallery: React.FC<FellowshipGalleryProps> = ({ settings }) => {
  const [selectedPhoto, setSelectedPhoto] = useState<GalleryImageItem | null>(null);
  const items: GalleryImageItem[] = settings.gallery && settings.gallery.length > 0
    ? settings.gallery
    : defaultGalleryItems;

  return (
    <section id="fellowship" className="relative w-full bg-[#F3EFE6] text-[#171916] py-16 sm:py-20 lg:py-24 border-b border-[#171916]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#171916]/10 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B66A43] font-semibold block mb-2">
              Chapter 05 · Community & Life
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#171916] tracking-tight">
              Moments of <br />
              <span className="italic text-[#183D32]">Fellowship & Adoration</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#171916]/70 max-w-sm tracking-wide">
            Glimpses into the life of our church family: unhurried laughter, corporate prayers, children's smiles, and the natural serenity of Nyeri County.
          </p>
        </motion.div>

        {/* Dynamic Masonry Grid */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-12 gap-4 sm:gap-6 lg:gap-8"
        >
          {items.map((item, idx) => {
            // Adaptive responsive column spans
            const isFeatured = idx % 3 === 0;
            const spanClass = isFeatured ? 'col-span-12 lg:col-span-8 aspect-[16/10]' : 'col-span-12 sm:col-span-6 lg:col-span-4 aspect-[4/3]';

            return (
              <div
                key={item.id}
                className={`${spanClass} relative group cursor-pointer overflow-hidden bg-[#183D32]/10 border border-[#171916]/10 shadow-sm`}
                onClick={() => setSelectedPhoto(item)}
              >
                <img loading="lazy" decoding="async"
                  src={item.src}
                  alt={item.title}
                  className="w-full h-full object-cover filter contrast-[1.02] group-hover:scale-103 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Fallback to placeholder if link broken
                    e.currentTarget.src = '/images/fellowship_community.webp';
                  }}
                />

                {/* Minimal Dark Scrim on Hover */}
                <div className="absolute inset-0 bg-[#171916]/65 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-4 sm:p-6 text-white">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-sans tracking-[0.2em] text-[#B69A62] font-semibold">
                      {item.figure || `Fig. 0${idx + 1}`} · {item.category}
                    </span>
                    <ZoomIn className="w-4 h-4 text-white/80" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg sm:text-xl font-medium">{item.title}</h3>
                    <p className="font-sans text-xs text-white/80 mt-1 line-clamp-2">{item.caption}</p>
                  </div>
                </div>

                {/* Quiet Default Bottom Label on Mobile */}
                <div className="absolute bottom-2.5 left-2.5 bg-[#171916]/85 text-[#F3EFE6] px-2 py-0.5 text-[9px] font-sans tracking-widest uppercase sm:hidden">
                  {item.figure || `Fig. 0${idx + 1}`}
                </div>
              </div>
            );
          })}
        </motion.div>

        {/* Caption Index Footer */}
        <div className="mt-8 border-t border-[#171916]/10 pt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 text-xs font-sans text-[#171916]/70">
          {items.slice(0, 4).map((item, idx) => (
            <div key={item.id} className="space-y-0.5">
              <span className="font-semibold text-[#183D32]">{item.figure || `Fig. 0${idx + 1}`} · {item.title}</span>
              <p className="text-[11px] text-[#171916]/60 leading-normal">{item.caption}</p>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Dialog */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedPhoto(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-[#171916] text-[#F3EFE6] border border-[#F3EFE6]/20 p-4 sm:p-6 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#F3EFE6]/10 mb-3">
              <div>
                <span className="text-[10px] sm:text-xs font-sans uppercase tracking-widest text-[#B69A62]">
                  {selectedPhoto.figure} · {selectedPhoto.category}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl font-normal mt-0.5">
                  {selectedPhoto.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedPhoto(null)}
                className="p-1.5 text-[#F3EFE6]/70 hover:text-white"
                aria-label="Close photo preview"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>

            <div className="relative aspect-[16/10] w-full bg-black overflow-hidden mb-3">
              <img loading="lazy" decoding="async"
                src={selectedPhoto.src}
                alt={selectedPhoto.title}
                className="w-full h-full object-contain"
              />
            </div>

            <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed max-w-2xl">
              {selectedPhoto.caption}
            </p>
          </div>
        </div>
      )}
    </section>
  );
};
