import React from 'react';
import { MessageCircle, Quote } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface PastorProfileProps {
  settings: ChurchSettings;
  onOpenPrayerModal: () => void;
}

export const PastorProfile: React.FC<PastorProfileProps> = ({
  settings,
  onOpenPrayerModal,
}) => {
  const pastor = settings.pastor || {
    chapter: 'Chapter 02 · Pastoral Leadership',
    title: 'A Shepherd’s Heart for Witima & Beyond',
    name: settings.pastorName || 'Pastor Sarah Waweru',
    subtitle: 'Senior Pastor · KAG Emmanuel Church Witima',
    imageSrc: '/images/pastor_sarah_waweru.webp',
    welcomeHeading: 'A Pastoral Welcome to Every Soul',
    welcomeQuote: '“Whoever you are, whatever storms you carry, there is a place reserved for you at the feet of Jesus.”',
    p1: 'Karibu sana to KAG Emmanuel Church Witima. As your pastor, my deepest longing is to see families healed, broken spirits restored by the unconditional love of Jesus Christ, and our young generation rising as men and women of unshakeable integrity in Kenya.',
    p2: 'In Witima, we know that life in the highlands carries both bountiful harvests and seasons of quiet struggle. Yet the name given to our church is Emmanuel—God with us! He is with the mother waking up at dawn to tend her crops, with the student revising under lamplight, and with the seeker longing for forgiveness and peace of mind.',
    p3: 'When you visit us this Sunday, you will not find a cold institution; you will find a home filled with genuine praise, heartfelt prayer, and warm Christian fellowship over a cup of hot highland tea.',
    officeHours: 'Tuesdays & Thursdays · 10:00 AM – 3:00 PM',
  };

  return (
    <section id="pastor" className="relative w-full bg-[#171916] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 overflow-hidden border-b border-[#F3EFE6]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#F3EFE6]/15 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B69A62] font-semibold block mb-2">
              {pastor.chapter}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE6] tracking-tight">
              {pastor.title}
            </h2>
          </div>
          <div className="text-left md:text-right">
            <span className="font-serif text-xl sm:text-2xl text-[#B69A62] block">
              {pastor.name}
            </span>
            <span className="font-sans text-[11px] sm:text-xs uppercase tracking-widest text-[#F3EFE6]/60">
              {pastor.subtitle}
            </span>
          </div>
        </motion.div>

        {/* Split Editorial Composition */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Column 1: Editorial Portrait */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 w-full max-w-md mx-auto lg:max-w-none"
          >
            <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#183D32]/20 border border-[#F3EFE6]/15 shadow-xl">
              <img loading="lazy" decoding="async"
                src={pastor.imageSrc}
                alt={pastor.name}
                className="w-full h-full object-cover object-top filter contrast-[1.02]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171916]/85 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 text-[#F3EFE6]">
                <span className="text-[9px] sm:text-[10px] font-sans uppercase tracking-[0.25em] text-[#B69A62] font-bold block">
                  ORDINATION & MINISTRY
                </span>
                <span className="font-serif text-base sm:text-lg text-white font-medium">
                  {pastor.name}
                </span>
                <p className="text-xs text-[#F3EFE6]/75 mt-0.5 font-sans">
                  Shepherding God's flock with grace, prayer, and humility in Othaya.
                </p>
              </div>
            </div>

            <div className="mt-2.5 flex justify-between text-[11px] font-sans text-[#F3EFE6]/50">
              <span>Fig. 03 · Pastoral Study</span>
              <span>Sanctuary Office, Witima</span>
            </div>
          </motion.div>

          {/* Column 2: Pastoral Epistle & Heart */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-5 lg:pl-2"
          >
            <div className="inline-flex items-center gap-2 text-xs font-sans tracking-widest uppercase text-[#B66A43] font-semibold">
              <Quote className="w-3.5 h-3.5 text-[#B69A62]" />
              <span>{pastor.welcomeHeading}</span>
            </div>

            <h3 className="font-serif text-2xl sm:text-3xl text-[#F3EFE6] leading-snug font-normal">
              {pastor.welcomeQuote}
            </h3>

            <div className="space-y-3.5 text-sm sm:text-base text-[#F3EFE6]/80 font-sans leading-relaxed">
              <p>{pastor.p1}</p>
              <p>{pastor.p2}</p>
              <p>{pastor.p3}</p>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-[#F3EFE6]/15 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <a
                href={`https://wa.me/${settings.mpesa.whatsappNumber}?text=Praise%20God%20Pastor%20Sarah,%20I%20am%20reaching%20out%20from%20the%20KAG%20Emmanuel%20Church%20Witima%20website.`}
                target="_blank"
                rel="noreferrer"
                className="px-6 py-3.5 bg-[#B66A43] text-white font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#B66A43]/90 transition-all flex items-center justify-center gap-2 text-center"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp {pastor.name}</span>
              </a>

              <button
                onClick={onOpenPrayerModal}
                className="px-6 py-3.5 border border-[#F3EFE6]/30 text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-medium hover:border-[#B69A62] hover:text-[#B69A62] transition-colors text-center"
              >
                Request Pastoral Prayer
              </button>
            </div>

            {/* Pastoral Office Hours */}
            <div className="pt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-sans text-[#F3EFE6]/60 border-t border-[#F3EFE6]/10">
              <div>
                <span className="text-[#B69A62] block font-semibold mb-0.5">Pastoral Consultations:</span>
                {pastor.officeHours}
              </div>
              <div>
                <span className="text-[#B69A62] block font-semibold mb-0.5">Direct Sanctuary Helpline:</span>
                {settings.mpesa.pastorContactPhone}
              </div>
            </div>

          </motion.div>

        </div>

      </div>
    </section>
  );
};
