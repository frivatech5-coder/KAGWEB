import React from 'react';
import { Calendar, Clock, MapPin, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { upcomingChurchEvents } from '../data/defaultChurchData';
import { ChurchSettings } from '../types/church';

interface UpcomingEventsProps {
  settings: ChurchSettings;
}

export const UpcomingEvents: React.FC<UpcomingEventsProps> = ({ settings }) => {
  return (
    <section className="relative w-full bg-[#F3EFE6] text-[#171916] py-16 sm:py-20 lg:py-24 border-b border-[#171916]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#171916]/10 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B66A43] font-semibold block mb-2">
              Chapter 07 · Seasonal Calendar
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#171916] tracking-tight">
              Upcoming Gatherings & <br />
              <span className="italic text-[#183D32]">Special Convocations</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#171916]/70 max-w-sm tracking-wide">
            Mark your calendar for our upcoming regional conferences, thanksgiving seasons, and youth camps in Witima.
          </p>
        </motion.div>

        {/* Magazine Style Events Calendar */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          {(settings.events && settings.events.length > 0 ? settings.events : upcomingChurchEvents).map((event, idx) => (
            <div
              key={event.id}
              className="border border-[#171916]/15 bg-white/45 p-6 sm:p-8 flex flex-col justify-between hover:border-[#183D32] transition-colors"
            >
              <div>
                <div className="flex items-center justify-between border-b border-[#171916]/10 pb-3 mb-5">
                  <span className="text-[9px] sm:text-[10px] font-sans uppercase tracking-[0.2em] text-[#B66A43] font-bold">
                    {event.tag}
                  </span>
                  <span className="font-serif italic text-xs sm:text-sm text-[#183D32] tabular-nums font-semibold">
                    NO. 0{idx + 1}
                  </span>
                </div>

                <div className="mb-4">
                  <span className="font-serif text-2xl sm:text-3xl font-medium text-[#183D32] block">
                    {event.date}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-sans text-[#171916]/65 mt-1">
                    <Clock className="w-3.5 h-3.5 text-[#B66A43]" />
                    <span>{event.time}</span>
                  </div>
                </div>

                <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#171916] leading-snug mb-2.5">
                  {event.title}
                </h3>

                <p className="font-sans text-xs sm:text-sm text-[#171916]/75 leading-relaxed mb-5">
                  {event.description}
                </p>

                <div className="flex items-start gap-2 text-xs font-sans text-[#171916]/70 mb-5">
                  <MapPin className="w-4 h-4 text-[#183D32] shrink-0 mt-0.5" />
                  <span>{event.venue}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#171916]/10">
                <a
                  href={`https://wa.me/${settings.mpesa.whatsappNumber}?text=Praise%20God,%20I%20would%20like%20more%20information%20regarding%20${encodeURIComponent(event.title)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 border border-[#171916]/20 text-[#171916] font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#183D32] hover:text-[#F3EFE6] hover:border-[#183D32] transition-all flex items-center justify-center gap-2 text-center"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Inquire on WhatsApp</span>
                </a>
              </div>
            </div>
          ))}
        </motion.div>

      </div>
    </section>
  );
};
