import React, { useState } from 'react';
import { Copy, Check, Smartphone, Heart, Sparkles, Edit3 } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface GivingMpesaProps {
  settings: ChurchSettings;
  onOpenAdminModal: () => void;
}

export const GivingMpesa: React.FC<GivingMpesaProps> = ({
  settings,
  onOpenAdminModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Tithe');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const categories = [
    { id: 'Tithe', label: 'Tithe (Fungu la Kumi)', code: 'TITHE' },
    { id: 'Building', label: 'Sanctuary Building Fund', code: 'BUILDING' },
    { id: 'Offering', label: 'Sunday General Offering', code: 'OFFERING' },
    { id: 'Benevolence', label: 'Widows & Mercy Benevolence', code: 'MERCY' },
    { id: 'Missions', label: 'Youth & Highland Missions', code: 'MISSIONS' },
  ];

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const currentCategoryCode = categories.find((c) => c.id === selectedCategory)?.code || 'OFFERING';

  return (
    <section id="giving" className="relative w-full bg-[#B66A43] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 overflow-hidden border-b border-[#F3EFE6]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#F3EFE6]/20 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#F3EFE6]/80 font-semibold block mb-2">
              {settings.giving?.chapter || 'Chapter 08 · Sacred Stewardship'}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE6] tracking-tight">
              {settings.giving?.title || 'Giving With Joy'} <br />
              <span className="italic text-[#171916]">{settings.giving?.subtitle || 'Safaricom M-Pesa'}</span>
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-serif italic text-sm sm:text-base text-[#F3EFE6]/90 max-w-sm">
              “{settings.giving?.quote || 'Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion.'}”
            </span>
          </div>
        </motion.div>

        {/* 2-Column Asymmetrical Giving Experience */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Column 1: M-Pesa Digital Terminal Card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-[#171916] text-[#F3EFE6] p-5 sm:p-8 lg:p-10 border border-[#F3EFE6]/20 shadow-2xl space-y-6 sm:space-y-7"
          >
            <div className="flex items-center justify-between border-b border-[#F3EFE6]/15 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#B69A62]" />
                <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.2em] text-[#B69A62] font-bold">
                  SAFARICOM M-PESA CHANNEL
                </span>
              </div>
              <button
                onClick={onOpenAdminModal}
                className="text-[11px] font-sans text-[#F3EFE6]/60 hover:text-[#B69A62] flex items-center gap-1 transition-colors"
                title="Edit M-Pesa Paybill or Till Number"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Codes</span>
              </button>
            </div>

            {/* Category Selector Tabs */}
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-sans tracking-widest text-[#F3EFE6]/60 block font-semibold">
                1. Select Giving Purpose (Account Designation)
              </span>
              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 text-xs font-sans font-medium transition-all ${
                      selectedCategory === cat.id
                        ? 'bg-[#B69A62] text-[#171916] font-semibold'
                        : 'bg-[#F3EFE6]/10 text-[#F3EFE6]/80 hover:bg-[#F3EFE6]/20'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* M-Pesa Coordinates Block */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-[#F3EFE6]/15">
              
              {/* Paybill Number Box */}
              <div className="bg-[#183D32]/40 p-4 sm:p-5 border border-[#F3EFE6]/10">
                <span className="text-[10px] uppercase font-sans tracking-widest text-[#B69A62] block font-semibold mb-1">
                  M-Pesa {settings.mpesa.type === 'paybill' ? 'Paybill Number' : 'Buy Goods Till'}
                </span>
                <div className="font-serif text-2xl sm:text-3xl font-bold text-[#F3EFE6] tracking-wider tabular-nums">
                  {settings.mpesa.number}
                </div>
                <button
                  onClick={() => handleCopy(settings.mpesa.number, 'paybill')}
                  className="mt-2.5 text-xs font-sans text-[#B69A62] hover:text-white flex items-center gap-1.5 transition-colors font-medium"
                >
                  {copiedField === 'paybill' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied to Clipboard</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Number</span>
                    </>
                  )}
                </button>
              </div>

              {/* Account Reference Box */}
              <div className="bg-[#183D32]/40 p-4 sm:p-5 border border-[#F3EFE6]/10">
                <span className="text-[10px] uppercase font-sans tracking-widest text-[#B69A62] block font-semibold mb-1">
                  Account Name / Reference
                </span>
                <div className="font-serif text-xl sm:text-2xl font-bold text-[#F3EFE6] tracking-wide truncate">
                  {currentCategoryCode} · {settings.mpesa.accountName}
                </div>
                <button
                  onClick={() =>
                    handleCopy(`${currentCategoryCode} ${settings.mpesa.accountName}`, 'account')
                  }
                  className="mt-2.5 text-xs font-sans text-[#B69A62] hover:text-white flex items-center gap-1.5 transition-colors font-medium"
                >
                  {copiedField === 'account' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied to Clipboard</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Account Ref</span>
                    </>
                  )}
                </button>
              </div>

            </div>

            {/* Business Verification */}
            <div className="text-xs font-sans text-[#F3EFE6]/60 flex flex-wrap items-center justify-between gap-2 border-t border-[#F3EFE6]/10 pt-3">
              <span>Account Name: <strong className="text-[#F3EFE6]">{settings.mpesa.businessName}</strong></span>
              <span className="text-[#B69A62]">Audited Parish Account</span>
            </div>

          </motion.div>

          {/* Column 2: Step-by-Step Instructions */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-5 lg:pl-2"
          >
            <div className="text-xs font-sans uppercase tracking-[0.25em] text-[#F3EFE6]/80 font-semibold">
              Step-by-Step Giving Guide
            </div>

            <ol className="space-y-3.5 font-sans text-xs sm:text-sm text-[#F3EFE6]/90 list-none">
              <li className="flex gap-3 items-start">
                <span className="w-5 h-5 bg-[#171916] text-[#F3EFE6] flex items-center justify-center font-serif text-xs font-bold shrink-0 mt-0.5">
                  1
                </span>
                <span>Open your Safaricom SIM Toolkit or M-Pesa App.</span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="w-5 h-5 bg-[#171916] text-[#F3EFE6] flex items-center justify-center font-serif text-xs font-bold shrink-0 mt-0.5">
                  2
                </span>
                <span>Select <strong>Lipa na M-Pesa</strong> → <strong>Paybill</strong>.</span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="w-5 h-5 bg-[#171916] text-[#F3EFE6] flex items-center justify-center font-serif text-xs font-bold shrink-0 mt-0.5">
                  3
                </span>
                <span>
                  Enter Business No: <strong className="underline underline-offset-4 font-serif text-base">{settings.mpesa.number}</strong>
                </span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="w-5 h-5 bg-[#171916] text-[#F3EFE6] flex items-center justify-center font-serif text-xs font-bold shrink-0 mt-0.5">
                  4
                </span>
                <span>
                  Enter Account: <strong className="font-semibold">{currentCategoryCode}</strong> followed by your Name.
                </span>
              </li>
              <li className="flex gap-3 items-start">
                <span className="w-5 h-5 bg-[#171916] text-[#F3EFE6] flex items-center justify-center font-serif text-xs font-bold shrink-0 mt-0.5">
                  5
                </span>
                <span>Enter Amount, key in your M-Pesa PIN, and confirm recipient: <strong>{settings.mpesa.businessName}</strong>.</span>
              </li>
            </ol>

            <div className="p-4 sm:p-5 bg-[#171916]/30 border border-[#F3EFE6]/20 space-y-1.5 mt-4">
              <span className="font-serif italic text-base sm:text-lg text-white block">
                Malachi 3:10
              </span>
              <p className="font-sans text-xs text-[#F3EFE6]/80 leading-relaxed">
                “Bring the whole tithe into the storehouse, that there may be food in my house. Test me in this,” says the LORD Almighty, “and see if I will not throw open the floodgates of heaven.”
              </p>
            </div>

            <p className="text-xs font-sans text-[#F3EFE6]/70">
              For direct bank instructions or diaspora support, contact Pastor Sarah at <span className="underline">{settings.mpesa.pastorContactPhone}</span>.
            </p>

          </motion.div>

        </div>

      </div>
    </section>
  );
};
