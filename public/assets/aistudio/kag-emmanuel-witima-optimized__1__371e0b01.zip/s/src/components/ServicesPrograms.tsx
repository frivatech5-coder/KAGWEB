import React, { useState } from 'react';
import { Clock, MapPin, Calendar, Check, Copy, Edit3 } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings, ChurchScheduleItem } from '../types/church';

interface ServicesProgramsProps {
  settings: ChurchSettings;
  onOpenAdminModal: () => void;
  onOpenVisitModal: () => void;
}

export const ServicesPrograms: React.FC<ServicesProgramsProps> = ({
  settings,
  onOpenAdminModal,
  onOpenVisitModal,
}) => {
  const [filter, setFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredSchedules = settings.schedules.filter((item) => {
    if (filter === 'all') return true;
    if (filter === 'sunday') return item.day === 'Sunday';
    if (filter === 'midweek') return item.day !== 'Sunday';
    if (filter === 'prayer') return item.category === 'prayer';
    return true;
  });

  const handleCopyDetails = (item: ChurchScheduleItem) => {
    const text = `${item.title} at ${settings.churchName}\nWhen: ${item.day}, ${item.time}\nWhere: ${item.location}, ${settings.locationString}`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <section id="schedule" className="relative w-full bg-[#F3EFE6] text-[#171916] py-16 sm:py-20 lg:py-24 border-b border-[#171916]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#171916]/10 pb-5 mb-10 sm:mb-12"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B66A43] font-semibold block mb-2">
              Chapter 03 · Liturgical Order
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#171916] tracking-tight">
              The Sacred Rhythm <br />
              <span className="italic text-[#183D32]">Weekly Gatherings</span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Filter Tabs */}
            <div className="inline-flex p-1 bg-[#171916]/5 border border-[#171916]/10 overflow-x-auto max-w-full">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1.5 text-xs font-sans font-medium transition-colors whitespace-nowrap ${
                  filter === 'all'
                    ? 'bg-[#183D32] text-[#F3EFE6]'
                    : 'text-[#171916]/70 hover:text-[#171916]'
                }`}
              >
                All Gatherings
              </button>
              <button
                onClick={() => setFilter('sunday')}
                className={`px-3 py-1.5 text-xs font-sans font-medium transition-colors whitespace-nowrap ${
                  filter === 'sunday'
                    ? 'bg-[#183D32] text-[#F3EFE6]'
                    : 'text-[#171916]/70 hover:text-[#171916]'
                }`}
              >
                Sunday Services
              </button>
              <button
                onClick={() => setFilter('midweek')}
                className={`px-3 py-1.5 text-xs font-sans font-medium transition-colors whitespace-nowrap ${
                  filter === 'midweek'
                    ? 'bg-[#183D32] text-[#F3EFE6]'
                    : 'text-[#171916]/70 hover:text-[#171916]'
                }`}
              >
                Mid-Week & Kesha
              </button>
            </div>

            <button
              onClick={onOpenAdminModal}
              className="inline-flex items-center gap-1.5 text-xs font-sans text-[#B66A43] hover:text-[#183D32] font-semibold tracking-wider uppercase underline underline-offset-4 transition-colors"
              title="Edit service times and descriptions"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Times</span>
            </button>
          </div>
        </motion.div>

        {/* Editorial Programmatic Ledger with Motion entrance */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="divide-y divide-[#171916]/15 border-t border-b border-[#171916]/15"
        >
          {filteredSchedules.map((item, idx) => (
            <div
              key={item.id}
              className="py-6 sm:py-8 grid grid-cols-1 md:grid-cols-12 gap-4 sm:gap-6 items-baseline group hover:bg-white/40 transition-colors px-1 sm:px-4"
            >
              {/* Day & Index */}
              <div className="md:col-span-3 flex items-baseline gap-3 sm:gap-4">
                <span className="font-serif italic text-base sm:text-lg text-[#B66A43] tabular-nums font-medium">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <div>
                  <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.2em] text-[#171916]/60 font-semibold block">
                    {item.day}
                  </span>
                  <span className="font-serif text-xl sm:text-2xl font-semibold text-[#183D32] tabular-nums block mt-0.5">
                    {item.time}
                  </span>
                </div>
              </div>

              {/* Title & Description */}
              <div className="md:col-span-6 space-y-1.5 sm:space-y-2">
                <div className="flex flex-wrap items-center gap-2.5">
                  <h3 className="font-serif text-lg sm:text-xl md:text-2xl font-bold text-[#171916] group-hover:text-[#183D32] transition-colors">
                    {item.title}
                  </h3>
                  <span className="text-[9px] sm:text-[10px] font-sans uppercase tracking-widest text-[#B66A43] font-bold">
                    {item.category}
                  </span>
                </div>
                <p className="font-sans text-xs sm:text-sm text-[#171916]/80 leading-relaxed max-w-xl">
                  {item.description}
                </p>
                <div className="flex items-center gap-1.5 text-xs font-sans text-[#171916]/60 pt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-[#B66A43] shrink-0" />
                  <span className="truncate">{item.location} · Witima Sanctuary</span>
                </div>
              </div>

              {/* Actions & Calendar: Fully Responsive Stacking */}
              <div className="md:col-span-3 flex flex-wrap md:justify-end items-center gap-2.5 pt-2 md:pt-0">
                <button
                  onClick={() => handleCopyDetails(item)}
                  className="px-3 py-1.5 text-xs font-sans font-medium text-[#171916] border border-[#171916]/20 hover:border-[#183D32] hover:text-[#183D32] transition-colors flex items-center gap-1.5"
                  title="Copy schedule to clipboard"
                >
                  {copiedId === item.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#183D32]" />
                      <span className="text-[#183D32]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#171916]/60" />
                      <span>Copy Details</span>
                    </>
                  )}
                </button>

                <button
                  onClick={onOpenVisitModal}
                  className="px-3.5 py-1.5 text-xs font-sans font-semibold tracking-wider uppercase bg-[#183D32] text-[#F3EFE6] hover:bg-[#171916] transition-colors"
                >
                  Attend
                </button>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Footnote on Liturgy */}
        <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center justify-between text-xs font-sans text-[#171916]/60 gap-3 pt-2">
          <p>
            * Translation into Kikuyu and Kiswahili is provided during Sunday main celebration and fellowship meetings.
          </p>
          <span className="font-semibold text-[#183D32]">
            All are welcome · No prior appointment required
          </span>
        </div>

      </div>
    </section>
  );
};
