import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { churchMinistries } from '../data/defaultChurchData';
import { ChurchSettings, Ministry } from '../types/church';

interface MinistriesShowcaseProps {
  settings: ChurchSettings;
  onOpenVisitModal: () => void;
}

export const MinistriesShowcase: React.FC<MinistriesShowcaseProps> = ({ settings, onOpenVisitModal }) => {
  const ministriesList: Ministry[] = settings.ministries && settings.ministries.length > 0
    ? settings.ministries
    : churchMinistries;

  const [activeMinistry, setActiveMinistry] = useState<Ministry>(ministriesList[0] || churchMinistries[0]);

  // Keep active ministry synced if list changed
  const currentMinistry = ministriesList.find((m) => m.id === activeMinistry.id) || ministriesList[0] || churchMinistries[0];

  return (
    <section id="ministries" className="relative w-full bg-[#183D32] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 border-b border-[#F3EFE6]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#F3EFE6]/15 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B69A62] font-semibold block mb-2">
              Chapter 06 · Body of Christ
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE6] tracking-tight">
              Ministries of <br />
              <span className="italic text-[#B66A43]">Purpose & Service</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/75 max-w-sm tracking-wide">
            Every age, every calling, and every gift has an active place of service and discipleship within the Emmanuel family.
          </p>
        </motion.div>

        {/* Asymmetrical 2-Column Ministry Ledger & Active Detail View */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Column 1: Ministry List Navigator */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-2"
          >
            <span className="text-[10px] uppercase font-sans tracking-[0.25em] text-[#B69A62] font-semibold block mb-3">
              Select A Ministry Pillar
            </span>

            <div className="divide-y divide-[#F3EFE6]/10 border-t border-b border-[#F3EFE6]/10">
              {ministriesList.map((min, index) => {
                const isSelected = currentMinistry.id === min.id;
                return (
                  <button
                    key={min.id}
                    onClick={() => setActiveMinistry(min)}
                    className={`w-full py-3.5 sm:py-4 text-left flex items-center justify-between transition-all group px-2 ${
                      isSelected
                        ? 'bg-[#F3EFE6]/10 text-white'
                        : 'hover:bg-[#F3EFE6]/5 text-[#F3EFE6]/80'
                    }`}
                  >
                    <div className="flex items-baseline gap-3 sm:gap-4 min-w-0">
                      <span className="font-serif italic text-xs sm:text-sm text-[#B69A62] tabular-nums shrink-0">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                      <div className="min-w-0">
                        <span className="font-serif text-base sm:text-lg lg:text-xl font-medium group-hover:text-[#B69A62] transition-colors block truncate">
                          {min.name}
                        </span>
                        <span className="font-sans text-[11px] text-[#F3EFE6]/60 truncate block">
                          {min.kicker}
                        </span>
                      </div>
                    </div>
                    <ArrowRight
                      className={`w-4 h-4 transition-transform shrink-0 ml-2 ${
                        isSelected ? 'translate-x-1 text-[#B69A62]' : 'opacity-30 group-hover:opacity-100'
                      }`}
                    />
                  </button>
                );
              })}
            </div>
          </motion.div>

          {/* Column 2: Selected Ministry Profile */}
          {currentMinistry && (
            <motion.div
              key={currentMinistry.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
              className="lg:col-span-7 bg-[#171916]/40 border border-[#F3EFE6]/15 p-6 sm:p-10 relative"
            >
              <div className="space-y-5">
                
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F3EFE6]/10 pb-3">
                  <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.2em] text-[#B69A62] font-semibold">
                    {currentMinistry.kicker}
                  </span>
                  <span className="font-serif italic text-xs sm:text-sm text-[#F3EFE6]/60">
                    {currentMinistry.scripture}
                  </span>
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl text-[#F3EFE6] font-normal leading-snug">
                  {currentMinistry.name}
                </h3>

                <p className="font-sans text-sm sm:text-base text-[#F3EFE6]/85 leading-relaxed">
                  {currentMinistry.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#F3EFE6]/10 text-xs font-sans">
                  <div>
                    <span className="text-[#B69A62] uppercase tracking-wider block font-semibold mb-0.5">
                      Ministry Leadership
                    </span>
                    <span className="text-white font-medium">{currentMinistry.lead}</span>
                  </div>

                  <div>
                    <span className="text-[#B69A62] uppercase tracking-wider block font-semibold mb-0.5">
                      Regular Gathering
                    </span>
                    <span className="text-white font-medium">{currentMinistry.meetingTime}</span>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    onClick={onOpenVisitModal}
                    className="w-full sm:w-auto px-6 py-3.5 bg-[#B66A43] text-white font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#B69A62] transition-colors flex items-center justify-center gap-2 text-center"
                  >
                    <span>Inquire or Join Fellowship</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            </motion.div>
          )}

        </div>

      </div>
    </section>
  );
};
