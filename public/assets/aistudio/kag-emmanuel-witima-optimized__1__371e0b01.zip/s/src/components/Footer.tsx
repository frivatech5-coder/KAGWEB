import React from 'react';
import { ArrowUp, MapPin, Phone, Mail, MessageCircle, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface FooterProps {
  settings: ChurchSettings;
  onOpenVisitModal: () => void;
  onOpenPrayerModal: () => void;
  onOpenAdminModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  onOpenVisitModal,
  onOpenPrayerModal,
  onOpenAdminModal,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative w-full bg-[#171916] text-[#F3EFE6] pt-16 sm:pt-20 pb-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Operational Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-12 sm:pb-16 border-b border-[#F3EFE6]/15"
        >
          {/* Identity & Motto */}
          <div className="md:col-span-5 space-y-5">
            <div className="flex items-center gap-3">
              <img decoding="async"
                src="/assets/aistudio/image_011cfb74.png"
                alt="Kenya Assemblies of God Seal"
                className="w-10 h-10 sm:w-12 sm:h-12 object-contain filter brightness-110 shrink-0"
              />
              <div className="min-w-0">
                <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-white block truncate">
                  KAG EMMANUEL WITIMA
                </span>
                <span className="font-sans text-[9px] sm:text-[10px] tracking-[0.2em] uppercase text-[#B69A62] font-semibold block">
                  Kenya Assemblies of God
                </span>
              </div>
            </div>

            <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/75 leading-relaxed max-w-sm">
              {settings.footer?.summary || 'An apostolic house of prayer, holy living, and Christian fellowship nestled in the tea highlands of Witima, Othaya, Nyeri County.'}
            </p>

            <div className="pt-1 text-xs font-serif italic text-[#B69A62]">
              {settings.footer?.motto || '“All the Gospel to all the world” — Assemblies of God Doctrinal Foundation'}
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-[10px] uppercase font-sans tracking-[0.25em] text-[#B69A62] font-bold block">
              Sanctuary Navigation
            </span>
            <ul className="space-y-2 font-sans text-xs tracking-wider text-[#F3EFE6]/80">
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  01. Heritage & Sanctuary
                </a>
              </li>
              <li>
                <a href="#pastor" className="hover:text-white transition-colors">
                  02. Pastor Sarah Waweru
                </a>
              </li>
              <li>
                <a href="#schedule" className="hover:text-white transition-colors">
                  03. Weekly Service Hours
                </a>
              </li>
              <li>
                <a href="#sermons" className="hover:text-white transition-colors">
                  04. Video Sermon Archive
                </a>
              </li>
              <li>
                <a href="#ministries" className="hover:text-white transition-colors">
                  05. Church Ministries
                </a>
              </li>
              <li>
                <a href="#fellowship" className="hover:text-white transition-colors">
                  06. Community Fellowship
                </a>
              </li>
              <li>
                <a href="#giving" className="hover:text-white transition-colors">
                  07. M-Pesa Giving
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-white transition-colors">
                  08. Location & Directions
                </a>
              </li>
            </ul>
          </div>

          {/* Contacts & Administration */}
          <div className="md:col-span-4 space-y-3.5">
            <span className="text-[10px] uppercase font-sans tracking-[0.25em] text-[#B69A62] font-bold block">
              Contact & Pastoral Office
            </span>

            <div className="space-y-2.5 text-xs font-sans text-[#F3EFE6]/80">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#B66A43] shrink-0 mt-0.5" />
                <span>Witima Market Centre, Off Othaya-Chinga Road, Nyeri County</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#B66A43] shrink-0" />
                <span>{settings.mpesa.pastorContactPhone} (Pastor Sarah)</span>
              </div>

              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#B66A43] shrink-0" />
                <a
                  href={`https://wa.me/${settings.mpesa.whatsappNumber}`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:underline text-[#B69A62]"
                >
                  WhatsApp: +{settings.mpesa.whatsappNumber}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#B66A43] shrink-0" />
                <span className="truncate">{settings.mpesa.email}</span>
              </div>
            </div>

            <div className="pt-3 flex flex-wrap items-center gap-2.5">
              <button
                onClick={onOpenVisitModal}
                className="px-3.5 py-2 bg-[#183D32] text-[#F3EFE6] font-sans text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43] transition-colors"
              >
                Plan Sunday Visit
              </button>
              <button
                onClick={onOpenPrayerModal}
                className="px-3.5 py-2 border border-[#F3EFE6]/20 text-[#F3EFE6] font-sans text-xs uppercase tracking-wider hover:border-[#B69A62] hover:text-[#B69A62] transition-colors"
              >
                Prayer Request
              </button>
            </div>
          </div>

        </motion.div>

        {/* Artistic Grand Headline: Responsive without horizontal overflow */}
        <div className="pt-10 sm:pt-14 pb-8 sm:pb-10 border-b border-[#F3EFE6]/10 text-center select-none overflow-hidden max-w-full">
          <div className="font-serif text-[clamp(1.75rem,6.5vw,5.5rem)] font-normal text-[#F3EFE6]/15 tracking-tight uppercase leading-tight sm:leading-none break-words">
            {settings.footer?.grandHeadline || 'KAG EMMANUEL WITIMA'}
          </div>
        </div>

        {/* Bottom Utility Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs font-sans text-[#F3EFE6]/50 gap-3">
          <div className="flex flex-wrap items-center gap-3 text-center sm:text-left">
            <span>© {new Date().getFullYear()} KAG Emmanuel Church Witima.</span>
            <button
              onClick={onOpenAdminModal}
              className="text-[#B69A62] hover:underline"
            >
              Parish Administration
            </button>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-[#F3EFE6]/70 hover:text-white transition-colors group shrink-0"
          >
            <span className="uppercase tracking-widest text-[10px]">Return To Top</span>
            <span className="p-1 border border-[#F3EFE6]/20 rounded-none group-hover:border-white transition-colors">
              <ArrowUp className="w-3 h-3" />
            </span>
          </button>
        </div>

      </div>
    </footer>
  );
};
