import React, { useState } from 'react';
import { Play, BookOpen, X } from 'lucide-react';
import { motion } from 'motion/react';
import { churchSermons } from '../data/defaultChurchData';
import { ChurchSettings, Sermon } from '../types/church';

interface SermonArchiveProps {
  settings: ChurchSettings;
}

export const SermonArchive: React.FC<SermonArchiveProps> = ({ settings }) => {
  const sermonsList = settings.sermons && settings.sermons.length > 0 ? settings.sermons : churchSermons;
  const [activeSermon, setActiveSermon] = useState<Sermon | null>(null);
  const leadSermon = sermonsList[0];
  const secondarySermons = sermonsList.slice(1);

  return (
    <section id="sermons" className="relative w-full bg-[#171916] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 border-b border-[#F3EFE6]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#F3EFE6]/15 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B69A62] font-semibold block mb-2">
              Chapter 04 · Expository Preaching
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE6] tracking-tight">
              The Living Word <br />
              <span className="italic text-[#B66A43]">Sermon Archive</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/70 max-w-sm tracking-wide">
            Expository messages delivered from the pulpit of KAG Emmanuel Church Witima, ministering faith, holiness, and hope.
          </p>
        </motion.div>

        {/* Lead Sermon Presentation */}
        {leadSermon && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="border border-[#F3EFE6]/15 bg-[#183D32]/25 p-5 sm:p-8 lg:p-10 mb-12 sm:mb-16"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-center">
              
              {/* Visual Thumbnail & Play Action */}
              <div className="lg:col-span-5 relative aspect-[16/9] w-full bg-[#171916] overflow-hidden border border-[#F3EFE6]/15 group">
                <img loading="lazy" decoding="async"
                  src={settings.hero?.imageSrc || "/images/hero_worship_witima.webp"}
                  alt={leadSermon.title}
                  className="w-full h-full object-cover filter brightness-75 group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-[#171916]/40 flex items-center justify-center">
                  <button
                    onClick={() => setActiveSermon(leadSermon)}
                    className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#B66A43] text-white flex items-center justify-center shadow-2xl hover:scale-110 hover:bg-[#B69A62] transition-all"
                    aria-label={`Play sermon: ${leadSermon.title}`}
                  >
                    <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-current translate-x-0.5" />
                  </button>
                </div>
                <div className="absolute bottom-2.5 left-2.5 bg-[#171916]/90 px-2 py-0.5 text-[9px] sm:text-[10px] font-sans tracking-widest uppercase text-[#B69A62]">
                  FEATURED EXPEDITION · {leadSermon.duration}
                </div>
              </div>

              {/* Sermon Metadata & Summary */}
              <div className="lg:col-span-7 space-y-3.5 sm:space-y-4">
                <div className="flex flex-wrap items-center gap-2 text-xs font-sans text-[#B69A62]">
                  <span className="uppercase tracking-wider font-semibold">{leadSermon.series}</span>
                  <span>·</span>
                  <span>{leadSermon.date}</span>
                  <span>·</span>
                  <span>{leadSermon.speaker}</span>
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl text-[#F3EFE6] font-normal leading-snug">
                  {leadSermon.title}
                </h3>

                <div className="flex items-center gap-2 text-xs font-sans text-[#B66A43] font-semibold">
                  <BookOpen className="w-4 h-4 shrink-0" />
                  <span>Scripture: {leadSermon.scripture}</span>
                </div>

                <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/80 leading-relaxed">
                  {leadSermon.summary}
                </p>

                <div className="p-3 sm:p-4 bg-[#171916]/60 border-l-2 border-[#B69A62] text-xs font-sans text-[#F3EFE6]/90 italic">
                  “{leadSermon.keyTakeaway}”
                </div>

                <div className="pt-2 flex items-center gap-4">
                  <button
                    onClick={() => setActiveSermon(leadSermon)}
                    className="w-full sm:w-auto px-5 py-3 bg-[#B66A43] text-white font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#B69A62] transition-colors flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Watch Message on YouTube</span>
                  </button>
                </div>
              </div>

            </div>
          </motion.div>
        )}

        {/* Secondary Sermons Grid */}
        {secondarySermons.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="border-t border-[#F3EFE6]/15 pt-8 sm:pt-10"
          >
            <div className="text-[10px] sm:text-xs uppercase font-sans tracking-[0.25em] text-[#B69A62] font-semibold mb-6">
              Recent Sermons & Teachings
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
              {secondarySermons.map((sermon) => (
                <div
                  key={sermon.id}
                  className="border border-[#F3EFE6]/10 p-5 sm:p-6 flex flex-col justify-between hover:border-[#B69A62]/40 transition-colors group"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-[11px] font-sans text-[#F3EFE6]/60">
                      <span className="uppercase tracking-wider text-[#B69A62]">{sermon.series}</span>
                      <span className="tabular-nums">{sermon.duration}</span>
                    </div>

                    <h4 className="font-serif text-lg sm:text-xl text-[#F3EFE6] group-hover:text-[#B69A62] transition-colors font-medium leading-snug">
                      {sermon.title}
                    </h4>

                    <div className="text-xs font-sans text-[#B66A43]">
                      {sermon.scripture}
                    </div>

                    <p className="font-sans text-xs text-[#F3EFE6]/70 leading-relaxed">
                      {sermon.summary}
                    </p>
                  </div>

                  <div className="pt-4 mt-5 border-t border-[#F3EFE6]/10 flex items-center justify-between">
                    <span className="text-[11px] font-sans text-[#F3EFE6]/50">
                      {sermon.speaker}
                    </span>
                    <button
                      onClick={() => setActiveSermon(sermon)}
                      className="text-xs font-sans text-[#F3EFE6] hover:text-[#B69A62] font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                    >
                      <span>Watch</span>
                      <Play className="w-3 h-3 fill-current" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

      </div>

      {/* YouTube Sermon Video Modal */}
      {activeSermon && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-4xl bg-[#171916] border border-[#F3EFE6]/20 p-4 sm:p-7 text-[#F3EFE6] shadow-2xl">
            <div className="flex items-start justify-between pb-3 border-b border-[#F3EFE6]/15 mb-3">
              <div className="pr-2">
                <span className="text-[10px] sm:text-xs font-sans uppercase tracking-widest text-[#B69A62]">
                  {activeSermon.series} · {activeSermon.speaker}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl font-normal mt-0.5">
                  {activeSermon.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveSermon(null)}
                className="p-1.5 text-[#F3EFE6]/60 hover:text-white shrink-0"
                aria-label="Close video player"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>

            <div className="relative aspect-[16/9] w-full bg-black mb-4">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${activeSermon.youtubeId}?autoplay=1&rel=0`}
                title={activeSermon.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-sans text-[#F3EFE6]/80 pt-2 border-t border-[#F3EFE6]/10">
              <div>
                <span className="font-semibold text-[#B69A62] block mb-0.5">Key Scripture:</span>
                {activeSermon.scripture}
              </div>
              <div>
                <span className="font-semibold text-[#B69A62] block mb-0.5">Summary Note:</span>
                {activeSermon.summary}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
