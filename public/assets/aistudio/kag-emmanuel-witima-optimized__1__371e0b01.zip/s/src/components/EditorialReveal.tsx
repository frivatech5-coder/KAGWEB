import React from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface EditorialRevealProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  /** Direction the element enters from */
  from?: 'up' | 'left' | 'right' | 'zoom';
}

export const EditorialReveal: React.FC<EditorialRevealProps> = ({
  children,
  delay = 0,
  className = '',
  from = 'up',
}) => {
  const reduce = useReducedMotion();
  const initial = reduce
    ? { opacity: 1 }
    : {
        opacity: 0,
        y: from === 'up' ? 28 : 0,
        x: from === 'left' ? -36 : from === 'right' ? 36 : 0,
        scale: from === 'zoom' ? 0.96 : 1,
      };
  return (
    <motion.div
      initial={initial}
      whileInView={{ opacity: 1, y: 0, x: 0, scale: 1 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
      style={{ willChange: 'transform, opacity' }}
    >
      {children}
    </motion.div>
  );
};
