import React from 'react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface ChurchStoryProps {
  settings: ChurchSettings;
}

export const ChurchStory: React.FC<ChurchStoryProps> = ({ settings }) => {
  const story = settings.story || {
    chapter: 'Chapter 01 · Heritage & Landscape',
    title: 'A Living Altar in The Central Highlands',
    subtitle: 'Nestled amid the mist-draped tea ridges of Othaya, Witima is where steadfast prayer meets the living power of the Holy Spirit.',
    essayParagraph1: 'Nestled at the eastern foothills of the Aberdare Ranges in Nyeri County, KAG Emmanuel Church Witima was planted with a singular, unwavering conviction: that God’s presence belongs in the everyday fabric of our village and marketplace. For decades, our church family has gathered in prayer, singing Kikuyu and Swahili hymns of salvation, lifting up farmers, teachers, shopkeepers, and young dreamers under one roof.',
    essayParagraph2: 'As part of the Kenya Assemblies of God (KAG)—a global fellowship founded upon Pentecostal truth and the baptism of the Holy Spirit—our sanctuary in Witima stands as a sanctuary of refuge. We believe that no matter where life has carried you, the blood of Jesus offers complete redemption.',
    pullQuote: '“We do not merely hold church services on Sundays; we nurture disciples who walk with Christ across the hills and tea slopes every sunrise.”',
    pullQuoteAuthor: 'Pastor Sarah Waweru, Senior Pastor',
    essayParagraph3: 'From our early days under modest timber roofs to the active, thriving fellowship of today, Emmanuel Church remains consecrated to sound biblical teaching, vibrant intercession, and family restoration throughout Othaya.',
    landscapeImageSrc: '/images/witima_nyeri_hills.webp',
    pillar1Title: '01. Scriptural Inerrancy',
    pillar1Desc: 'Grounded in the inspired, infallible Word of God as our supreme guide for doctrine and life.',
    pillar2Title: '02. Pentecostal Fire',
    pillar2Desc: 'Experiencing the real, supernatural baptism and gifts of the Holy Spirit for ministry power.',
    pillar3Title: '03. Covenant Fellowship',
    pillar3Desc: 'A loving spiritual family where every mother, father, youth, and child is seen and cherished.',
    pillar4Title: '04. Highlands Compassion',
    pillar4Desc: 'Extending Christ’s hands through food benevolence, hospital visitation, and youth empowerment.',
  };

  return (
    <section id="about" className="relative w-full bg-[#F3EFE6] text-[#171916] py-16 sm:py-20 lg:py-24 border-b border-[#171916]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#171916]/10 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B66A43] font-semibold block mb-2">
              {story.chapter}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#171916] tracking-tight">
              {story.title}
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#171916]/75 max-w-sm tracking-wide">
            {story.subtitle}
          </p>
        </motion.div>

        {/* Asymmetrical 2-Column Editorial Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          
          {/* Column 1: Editorial Essay with Drop Cap */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 space-y-5"
          >
            <p className="editorial-drop-cap font-sans text-base sm:text-lg text-[#171916]/90 leading-relaxed">
              {story.essayParagraph1}
            </p>

            <p className="font-sans text-sm sm:text-base text-[#171916]/80 leading-relaxed">
              {story.essayParagraph2}
            </p>

            {/* Editorial Pull Quote */}
            <div className="py-5 border-y border-[#171916]/10 my-6">
              <p className="font-serif italic text-xl sm:text-2xl text-[#183D32] leading-snug">
                {story.pullQuote}
              </p>
              <span className="font-sans text-xs uppercase tracking-widest text-[#B66A43] font-semibold block mt-2.5">
                — {story.pullQuoteAuthor}
              </span>
            </div>

            <p className="font-sans text-sm sm:text-base text-[#171916]/80 leading-relaxed">
              {story.essayParagraph3}
            </p>
          </motion.div>

          {/* Column 2: Panoramic Highlands Landscape */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 space-y-6"
          >
            <div className="relative aspect-[16/10] overflow-hidden bg-[#183D32]/10 shadow-md border border-[#171916]/10">
              <img loading="lazy" decoding="async"
                src={story.landscapeImageSrc}
                alt="Landscape surrounding Emmanuel Sanctuary"
                className="w-full h-full object-cover filter contrast-[1.03]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 right-3 bg-[#171916]/85 text-[#F3EFE6] px-2.5 py-1 text-[9px] sm:text-[10px] font-sans tracking-widest uppercase">
                NYERI COUNTY · ELEVATION ~1,850M
              </div>
            </div>
            
            <div className="flex items-start justify-between text-xs font-sans text-[#171916]/60 border-b border-[#171916]/10 pb-2.5">
              <span>Fig. 02 · Witima Landscape</span>
              <span>Aberdare foothills surrounding Emmanuel Sanctuary</span>
            </div>

            {/* 4 Sanctuary Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-1">
              <div className="border-t border-[#171916]/15 pt-3.5">
                <span className="font-serif text-base sm:text-lg font-bold text-[#183D32] block">
                  {story.pillar1Title}
                </span>
                <p className="font-sans text-xs text-[#171916]/75 mt-1 leading-relaxed">
                  {story.pillar1Desc}
                </p>
              </div>

              <div className="border-t border-[#171916]/15 pt-3.5">
                <span className="font-serif text-base sm:text-lg font-bold text-[#183D32] block">
                  {story.pillar2Title}
                </span>
                <p className="font-sans text-xs text-[#171916]/75 mt-1 leading-relaxed">
                  {story.pillar2Desc}
                </p>
              </div>

              <div className="border-t border-[#171916]/15 pt-3.5">
                <span className="font-serif text-base sm:text-lg font-bold text-[#183D32] block">
                  {story.pillar3Title}
                </span>
                <p className="font-sans text-xs text-[#171916]/75 mt-1 leading-relaxed">
                  {story.pillar3Desc}
                </p>
              </div>

              <div className="border-t border-[#171916]/15 pt-3.5">
                <span className="font-serif text-base sm:text-lg font-bold text-[#183D32] block">
                  {story.pillar4Title}
                </span>
                <p className="font-sans text-xs text-[#171916]/75 mt-1 leading-relaxed">
                  {story.pillar4Desc}
                </p>
              </div>
            </div>

          </motion.div>

        </div>

      </div>
    </section>
  );
};
