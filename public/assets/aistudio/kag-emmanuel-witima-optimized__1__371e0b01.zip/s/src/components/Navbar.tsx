import React, { useState } from 'react';
import { Menu, X, ArrowUpRight, ShieldCheck, HeartHandshake, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface NavbarProps {
  settings: ChurchSettings;
  onOpenVisitModal: () => void;
  onOpenPrayerModal: () => void;
  onOpenAdminModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  onOpenVisitModal,
  onOpenPrayerModal,
  onOpenAdminModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-[#F3EFE6]/95 backdrop-blur-md border-b border-[#171916]/10 transition-all">
        {/* Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-[60px] sm:h-[72px] flex items-center justify-between gap-4">
          
          {/* Left: Compact Church Identity */}
          <a
            href="#"
            className="flex items-center gap-2.5 sm:gap-3 group text-left min-w-0 shrink focus-visible:outline-none"
            aria-label="KAG Emmanuel Church Witima Home"
          >
            <img decoding="async"
              src="/assets/aistudio/image_011cfb74.png"
              alt="Kenya Assemblies of God Seal"
              className="w-[38px] h-[38px] sm:w-[42px] sm:h-[42px] object-contain drop-shadow-sm group-hover:scale-105 transition-transform shrink-0"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <div className="flex flex-col min-w-0">
              <span className="font-serif text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-[#171916] leading-tight truncate group-hover:text-[#183D32] transition-colors">
                KAG EMMANUEL
              </span>
              <span className="font-sans text-[9px] sm:text-[10px] tracking-[0.2em] uppercase text-[#B66A43] font-semibold leading-tight">
                Witima · Othaya
              </span>
            </div>
          </a>

          {/* Center (Desktop): Single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-[13px] font-sans font-medium text-[#171916]/80 tracking-wider uppercase shrink-0">
            <a
              href="#about"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              Sanctuary
            </a>
            <a
              href="#pastor"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              Pastor Sarah
            </a>
            <a
              href="#schedule"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              Sacred Rhythm
            </a>
            <a
              href="#sermons"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              Sermons
            </a>
            <a
              href="#giving"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              M-Pesa Giving
            </a>
            <a
              href="#location"
              className="hover:text-[#183D32] hover:underline underline-offset-8 transition-colors whitespace-nowrap"
            >
              Directions
            </a>
          </nav>

          {/* Right: Actions on Desktop, Hamburger Icon on Mobile */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            
            {/* Desktop Actions */}
            <div className="hidden lg:flex items-center gap-3">
              <button
                onClick={onOpenPrayerModal}
                className="px-3 py-2 text-xs font-sans tracking-wide text-[#183D32] border border-[#183D32]/30 hover:bg-[#183D32]/5 transition-colors whitespace-nowrap"
              >
                Prayer Request
              </button>

              <button
                onClick={onOpenVisitModal}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-sans font-semibold tracking-wider uppercase bg-[#183D32] text-[#F3EFE6] hover:bg-[#171916] transition-colors whitespace-nowrap shadow-sm"
              >
                <span>Plan Your Visit</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onOpenAdminModal}
                className="p-2 text-[#171916]/40 hover:text-[#183D32] transition-colors"
                title="Parish Administration & Times Editor"
                aria-label="Open Church Settings Editor"
              >
                <ShieldCheck className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Hamburger Button (Far right, no overflow) */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 text-[#171916] hover:text-[#183D32] transition-colors focus-visible:outline-none shrink-0"
              aria-label="Open navigation menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Animated Editorial Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 lg:hidden flex flex-col bg-[#171916] text-[#F3EFE6]"
          >
            {/* Drawer Header */}
            <div className="px-5 h-[60px] flex items-center justify-between border-b border-[#F3EFE6]/10 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <img decoding="async"
                  src="/assets/aistudio/image_011cfb74.png"
                  alt="KAG Seal"
                  className="w-[34px] h-[34px] object-contain shrink-0"
                />
                <span className="font-serif text-base tracking-wide text-[#F3EFE6] truncate">
                  KAG EMMANUEL WITIMA
                </span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 -mr-1 text-[#F3EFE6]/70 hover:text-white shrink-0"
                aria-label="Close menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col justify-between space-y-6">
              <nav className="flex flex-col space-y-4 font-serif text-lg sm:text-xl">
                <a
                  href="#about"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  01. The Sanctuary & Heritage
                </a>
                <a
                  href="#pastor"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  02. Pastor Sarah Waweru
                </a>
                <a
                  href="#schedule"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  03. Weekly Sacred Rhythm
                </a>
                <a
                  href="#sermons"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  04. Sermon Archive & The Word
                </a>
                <a
                  href="#ministries"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  05. Church Ministries
                </a>
                <a
                  href="#fellowship"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  06. Fellowship & Gallery
                </a>
                <a
                  href="#giving"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  07. M-Pesa Giving
                </a>
                <a
                  href="#location"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 text-[#F3EFE6]/90 hover:text-[#B69A62] transition-colors"
                >
                  08. Location & Directions
                </a>
              </nav>

              {/* Drawer Actions */}
              <div className="pt-4 border-t border-[#F3EFE6]/10 flex flex-col space-y-3 shrink-0">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenVisitModal();
                  }}
                  className="w-full py-3.5 bg-[#B66A43] text-white font-sans text-xs uppercase tracking-widest font-semibold flex items-center justify-center gap-2"
                >
                  <span>Plan Sunday Visit</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenPrayerModal();
                  }}
                  className="w-full py-3.5 border border-[#F3EFE6]/25 text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-medium hover:border-[#B69A62]"
                >
                  Send Prayer Petition
                </button>

                <div className="pt-2 flex items-center justify-between text-xs text-[#F3EFE6]/50 font-sans">
                  <span>Witima, Othaya, Kenya</span>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenAdminModal();
                    }}
                    className="text-[#B69A62] hover:underline"
                  >
                    Admin Mode
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
