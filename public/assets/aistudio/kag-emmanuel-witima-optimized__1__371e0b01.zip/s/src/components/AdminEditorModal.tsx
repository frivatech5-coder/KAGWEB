import React, { useState } from 'react';
import {
  X,
  Save,
  RotateCcw,
  ShieldCheck,
  Check,
  Cloud,
  Loader2,
  Image as ImageIcon,
  Type,
  BookOpen,
  UserCheck,
  Clock,
  Video,
  Users,
  CreditCard,
  MapPin,
  Plus,
  Trash2,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';
import {
  ChurchSettings,
  GalleryImageItem,
  ChurchScheduleItem,
  Sermon,
  Ministry,
  ChurchEvent,
} from '../types/church';

interface AdminEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ChurchSettings;
  onSaveSettings: (newSettings: ChurchSettings) => Promise<void> | void;
  onResetSettings: () => void;
}

type TabKey =
  | 'gallery'
  | 'hero'
  | 'scripture_story'
  | 'pastor'
  | 'services'
  | 'sermons'
  | 'ministries_events'
  | 'giving'
  | 'directions_footer';

export const AdminEditorModal: React.FC<AdminEditorModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onResetSettings,
}) => {
  const [formData, setFormData] = useState<ChurchSettings>(settings);
  const [activeTab, setActiveTab] = useState<TabKey>('gallery');
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New gallery image draft state
  const [newImage, setNewImage] = useState<Omit<GalleryImageItem, 'id'>>({
    title: '',
    caption: '',
    figure: `Fig. 0${(formData.gallery?.length || 0) + 1}`,
    src: '',
    category: 'Fellowship',
  });
  const [showAddImageForm, setShowAddImageForm] = useState(false);

  if (!isOpen) return null;

  // --- Handlers for Gallery Images ---
  const handleAddGalleryImage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newImage.src.trim() || !newImage.title.trim()) return;

    const newItem: GalleryImageItem = {
      id: `gallery_${Date.now()}`,
      title: newImage.title.trim(),
      caption: newImage.caption.trim() || 'Fellowship and prayer at KAG Emmanuel Church Witima.',
      figure: newImage.figure.trim() || `Fig. 0${(formData.gallery?.length || 0) + 1}`,
      src: newImage.src.trim(),
      category: newImage.category.trim() || 'Fellowship',
    };

    setFormData({
      ...formData,
      gallery: [...(formData.gallery || []), newItem],
    });

    setNewImage({
      title: '',
      caption: '',
      figure: `Fig. 0${(formData.gallery?.length || 0) + 2}`,
      src: '',
      category: 'Fellowship',
    });
    setShowAddImageForm(false);
  };

  const handleRemoveGalleryImage = (id: string) => {
    setFormData({
      ...formData,
      gallery: (formData.gallery || []).filter((item) => item.id !== id),
    });
  };

  const handleUpdateGalleryImage = (index: number, field: keyof GalleryImageItem, value: string) => {
    const list = [...(formData.gallery || [])];
    list[index] = { ...list[index], [field]: value };
    setFormData({ ...formData, gallery: list });
  };

  // --- Handlers for Schedules ---
  const handleScheduleChange = (index: number, field: keyof ChurchScheduleItem, value: string) => {
    const list = [...formData.schedules];
    list[index] = { ...list[index], [field]: value };
    setFormData({ ...formData, schedules: list });
  };

  const handleAddSchedule = () => {
    const newItem: ChurchScheduleItem = {
      id: `schedule_${Date.now()}`,
      day: 'Sunday',
      title: 'New Service',
      time: '09:00 AM — 11:30 AM',
      description: 'Congregational gathering for prayer and expository preaching.',
      location: 'Main Sanctuary',
      category: 'worship',
    };
    setFormData({
      ...formData,
      schedules: [...formData.schedules, newItem],
    });
  };

  const handleRemoveSchedule = (id: string) => {
    setFormData({
      ...formData,
      schedules: formData.schedules.filter((s) => s.id !== id),
    });
  };

  // --- Handlers for Sermons ---
  const handleSermonChange = (index: number, field: keyof Sermon, value: string) => {
    const list = [...(formData.sermons || [])];
    list[index] = { ...list[index], [field]: value };
    setFormData({ ...formData, sermons: list });
  };

  const handleAddSermon = () => {
    const newSermon: Sermon = {
      id: `sermon_${Date.now()}`,
      title: 'Walking in Divine Purpose',
      series: 'The Life of Faith',
      speaker: 'Pastor Sarah Waweru',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      scripture: 'Hebrews 11:1-6',
      duration: '48 mins',
      youtubeId: 'kJQP7kiw5Fk',
      summary: 'A message on unwavering trust in the promises of God.',
      keyTakeaway: 'Faith is the substance of things hoped for.',
    };
    setFormData({
      ...formData,
      sermons: [...(formData.sermons || []), newSermon],
    });
  };

  const handleRemoveSermon = (id: string) => {
    setFormData({
      ...formData,
      sermons: (formData.sermons || []).filter((s) => s.id !== id),
    });
  };

  // --- Handlers for Ministries ---
  const handleMinistryChange = (index: number, field: keyof Ministry, value: string) => {
    const list = [...(formData.ministries || [])];
    list[index] = { ...list[index], [field]: value };
    setFormData({ ...formData, ministries: list });
  };

  const handleAddMinistry = () => {
    const newMinistry: Ministry = {
      id: `ministry_${Date.now()}`,
      name: 'New Ministry Fellowship',
      kicker: 'Kingdom Service',
      scripture: '1 Corinthians 12:4-7',
      description: 'Dedicated to serving the church and community with Christlike love.',
      lead: 'Deacon Ministry Board',
      meetingTime: 'Saturdays at 3:00 PM',
    };
    setFormData({
      ...formData,
      ministries: [...(formData.ministries || []), newMinistry],
    });
  };

  const handleRemoveMinistry = (id: string) => {
    setFormData({
      ...formData,
      ministries: (formData.ministries || []).filter((m) => m.id !== id),
    });
  };

  // --- Handlers for Events ---
  const handleEventChange = (index: number, field: keyof ChurchEvent, value: string) => {
    const list = [...(formData.events || [])];
    list[index] = { ...list[index], [field]: value };
    setFormData({ ...formData, events: list });
  };

  const handleAddEvent = () => {
    const newEvent: ChurchEvent = {
      id: `event_${Date.now()}`,
      title: 'Highlands Revival & Prayer Conference',
      date: 'Next Month',
      time: '9:00 AM — 4:00 PM',
      venue: 'Emmanuel Main Sanctuary, Witima',
      description: 'Days of consecrated fasting, apostolic prayer, and Holy Spirit empowerment.',
      tag: 'Sanctuary Gathering',
    };
    setFormData({
      ...formData,
      events: [...(formData.events || []), newEvent],
    });
  };

  const handleRemoveEvent = (id: string) => {
    setFormData({
      ...formData,
      events: (formData.events || []).filter((e) => e.id !== id),
    });
  };

  // --- Form Submission (Firebase Firestore sync) ---
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveSettings(formData);
      setSavedSuccess(true);
      setTimeout(() => {
        setSavedSuccess(false);
        setIsSaving(false);
        onClose();
      }, 1500);
    } catch (err) {
      console.error('Error saving to Firebase:', err);
      setIsSaving(false);
    }
  };

  const tabs: { key: TabKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: 'gallery', label: 'Images & Visuals', icon: ImageIcon },
    { key: 'hero', label: 'Hero & Identity', icon: Type },
    { key: 'scripture_story', label: 'Scripture & Story', icon: BookOpen },
    { key: 'pastor', label: 'Pastor Profile', icon: UserCheck },
    { key: 'services', label: 'Weekly Services', icon: Clock },
    { key: 'sermons', label: 'Sermon Archive', icon: Video },
    { key: 'ministries_events', label: 'Ministries & Events', icon: Users },
    { key: 'giving', label: 'M-Pesa Giving', icon: CreditCard },
    { key: 'directions_footer', label: 'Directions & Footer', icon: MapPin },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-5xl bg-[#F3EFE6] text-[#171916] border border-[#171916]/30 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Top Header Bar */}
        <div className="px-4 sm:px-6 py-4 bg-[#183D32] text-[#F3EFE6] flex items-center justify-between shrink-0 border-b border-[#F3EFE6]/15">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#B66A43] text-white shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-sans text-[10px] uppercase tracking-[0.2em] text-[#B69A62] font-bold block">
                  Sanctuary Administration & Content Manager
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] font-sans px-2 py-0.5 bg-emerald-950/80 text-emerald-300 font-semibold border border-emerald-400/30">
                  <Cloud className="w-3 h-3 text-emerald-400" />
                  <span>Firebase Firestore Synced</span>
                </span>
              </div>
              <h3 className="font-serif text-xl sm:text-2xl font-medium text-white mt-0.5">
                KAG Emmanuel Church Witima · CMS
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 bg-[#B66A43] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B69A62] transition-colors disabled:opacity-60"
            >
              {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              <span>{isSaving ? 'Saving...' : 'Save to Firebase'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#F3EFE6]/70 hover:text-white transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Strip (Horizontally Scrollable) */}
        <div className="flex items-center gap-1 px-4 sm:px-6 py-2 bg-stone-200/90 border-b border-[#171916]/15 overflow-x-auto no-scrollbar shrink-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-sans whitespace-nowrap transition-all border-b-2 ${
                  isActive
                    ? 'border-[#183D32] bg-[#F3EFE6] text-[#183D32] font-bold shadow-xs'
                    : 'border-transparent text-[#171916]/70 hover:text-[#171916] hover:bg-[#F3EFE6]/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#B66A43]' : 'text-stone-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Success Banner */}
        {savedSuccess ? (
          <div className="p-8 sm:p-12 text-center space-y-3 my-auto">
            <div className="w-14 h-14 mx-auto bg-[#183D32] text-[#F3EFE6] flex items-center justify-center">
              <Check className="w-7 h-7 text-[#B69A62]" />
            </div>
            <h4 className="font-serif text-2xl sm:text-3xl font-bold text-[#183D32]">
              All Changes Saved & Synced to Firebase!
            </h4>
            <p className="font-sans text-xs sm:text-sm text-[#171916]/75 max-w-md mx-auto">
              Your edits to church texts, images, and schedules have been written to Firebase Firestore and are now active in real time.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

            {/* TAB 1: GALLERY & SITE IMAGES */}
            {activeTab === 'gallery' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#171916]/15 pb-3">
                  <div>
                    <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                      Community Gallery & Key Site Images
                    </h4>
                    <p className="font-sans text-xs text-[#171916]/70">
                      Add, remove, or replace images across the website. Paste any image URL or asset path.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddImageForm(!showAddImageForm)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43] transition-colors self-start sm:self-auto"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddImageForm ? 'Close Add Form' : 'Add New Gallery Image'}</span>
                  </button>
                </div>

                {/* Add Image Form */}
                {showAddImageForm && (
                  <div className="p-4 sm:p-5 bg-white border border-[#183D32]/25 shadow-sm space-y-4">
                    <span className="font-serif text-lg font-semibold text-[#183D32] block">
                      Add New Image to Fellowship Gallery
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                          Image URL * (Web URL or local path like /images/...)
                        </label>
                        <input
                          type="text"
                          required
                          value={newImage.src}
                          onChange={(e) => setNewImage({ ...newImage, src: e.target.value })}
                          placeholder="https://example.com/worship.jpg or /images/fellowship.webp"
                          className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                          Figure Label (e.g. Fig. 05)
                        </label>
                        <input
                          type="text"
                          value={newImage.figure}
                          onChange={(e) => setNewImage({ ...newImage, figure: e.target.value })}
                          className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                          Category / Department
                        </label>
                        <input
                          type="text"
                          value={newImage.category}
                          onChange={(e) => setNewImage({ ...newImage, category: e.target.value })}
                          placeholder="Worship / Fellowship / Children / Youth"
                          className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                          Image Title *
                        </label>
                        <input
                          type="text"
                          required
                          value={newImage.title}
                          onChange={(e) => setNewImage({ ...newImage, title: e.target.value })}
                          placeholder="e.g. Sunday Morning Choir Worship"
                          className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                          Caption / Story
                        </label>
                        <textarea
                          rows={2}
                          value={newImage.caption}
                          onChange={(e) => setNewImage({ ...newImage, caption: e.target.value })}
                          placeholder="Describe the occasion, moment, or community activity..."
                          className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddImageForm(false)}
                        className="px-3 py-1.5 text-xs text-[#171916]/70 hover:text-[#171916]"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleAddGalleryImage}
                        className="px-4 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43]"
                      >
                        Confirm Add Image
                      </button>
                    </div>
                  </div>
                )}

                {/* Key Site Images (Hero, Landscape, Pastor Portrait) */}
                <div className="p-4 bg-white/70 border border-[#171916]/15 space-y-4">
                  <span className="font-serif text-lg font-bold text-[#183D32] block">
                    Featured Site Visuals & Portraits
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Hero Background Image URL
                      </label>
                      <input
                        type="text"
                        value={formData.hero.imageSrc}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, imageSrc: e.target.value } })
                        }
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-mono"
                      />
                      {formData.hero.imageSrc && (
                        <div className="mt-2 aspect-video bg-stone-100 overflow-hidden border border-[#171916]/10">
                          <img loading="lazy" decoding="async"
                            src={formData.hero.imageSrc}
                            alt="Hero Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Story Landscape Image URL
                      </label>
                      <input
                        type="text"
                        value={formData.story.landscapeImageSrc}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, landscapeImageSrc: e.target.value },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-mono"
                      />
                      {formData.story.landscapeImageSrc && (
                        <div className="mt-2 aspect-video bg-stone-100 overflow-hidden border border-[#171916]/10">
                          <img loading="lazy" decoding="async"
                            src={formData.story.landscapeImageSrc}
                            alt="Landscape Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Pastor Sarah Portrait Image URL
                      </label>
                      <input
                        type="text"
                        value={formData.pastor.imageSrc}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            pastor: { ...formData.pastor, imageSrc: e.target.value },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-mono"
                      />
                      {formData.pastor.imageSrc && (
                        <div className="mt-2 aspect-square max-w-[120px] bg-stone-100 overflow-hidden border border-[#171916]/10">
                          <img loading="lazy" decoding="async"
                            src={formData.pastor.imageSrc}
                            alt="Pastor Portrait Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Current Gallery Items List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-serif text-lg font-bold text-[#183D32]">
                      Fellowship Gallery Collection ({(formData.gallery || []).length} photos)
                    </span>
                    <span className="text-xs text-[#171916]/60">Click remove or edit in place</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {(formData.gallery || []).map((item, idx) => (
                      <div
                        key={item.id}
                        className="p-3.5 bg-white border border-[#171916]/15 flex flex-col justify-between gap-3 shadow-xs"
                      >
                        <div className="flex gap-3">
                          <div className="w-20 h-20 bg-stone-100 shrink-0 border border-[#171916]/10 overflow-hidden">
                            <img loading="lazy" decoding="async"
                              src={item.src}
                              alt={item.title}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.src = '/images/fellowship_community.webp';
                              }}
                            />
                          </div>
                          <div className="flex-1 min-w-0 space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] uppercase font-sans tracking-wider text-[#B66A43] font-bold">
                                {item.figure} · {item.category}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleRemoveGalleryImage(item.id)}
                                className="text-rose-700 hover:text-rose-950 p-1"
                                title="Remove this image"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <input
                              type="text"
                              value={item.title}
                              onChange={(e) => handleUpdateGalleryImage(idx, 'title', e.target.value)}
                              className="w-full text-xs font-serif font-bold text-[#183D32] bg-stone-50 px-1.5 py-0.5 border border-[#171916]/10"
                            />
                            <textarea
                              rows={2}
                              value={item.caption}
                              onChange={(e) => handleUpdateGalleryImage(idx, 'caption', e.target.value)}
                              className="w-full text-[11px] font-sans text-[#171916]/80 bg-stone-50 px-1.5 py-0.5 border border-[#171916]/10"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] uppercase tracking-wider text-[#171916]/60 mb-0.5">
                            Image Source URL
                          </label>
                          <input
                            type="text"
                            value={item.src}
                            onChange={(e) => handleUpdateGalleryImage(idx, 'src', e.target.value)}
                            className="w-full text-[11px] font-mono bg-stone-50 px-2 py-1 border border-[#171916]/10 text-stone-700 truncate"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: HERO & GENERAL IDENTITY */}
            {activeTab === 'hero' && (
              <div className="space-y-6">
                <div className="border-b border-[#171916]/15 pb-2">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    Hero Section & General Identity Texts
                  </h4>
                  <p className="font-sans text-xs text-[#171916]/70">
                    Edit the main titles, headlines, tagline, and call to actions.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Church Name
                    </label>
                    <input
                      type="text"
                      value={formData.churchName}
                      onChange={(e) => setFormData({ ...formData, churchName: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Location String
                    </label>
                    <input
                      type="text"
                      value={formData.locationString}
                      onChange={(e) => setFormData({ ...formData, locationString: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Senior Pastor Name
                    </label>
                    <input
                      type="text"
                      value={formData.pastorName}
                      onChange={(e) => setFormData({ ...formData, pastorName: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Annual Spiritual Theme
                    </label>
                    <input
                      type="text"
                      value={formData.annualTheme}
                      onChange={(e) => setFormData({ ...formData, annualTheme: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-[#171916]/10">
                  <span className="font-serif text-lg font-bold text-[#183D32] block">
                    Hero Editorial Typography
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Hero Label / Tagline
                      </label>
                      <input
                        type="text"
                        value={formData.hero.label}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, label: e.target.value } })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Primary CTA Button Text
                      </label>
                      <input
                        type="text"
                        value={formData.hero.ctaPrimary}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, ctaPrimary: e.target.value } })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Main Headline Line 1
                      </label>
                      <input
                        type="text"
                        value={formData.hero.headlinePart1}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: { ...formData.hero, headlinePart1: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif text-base"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Main Headline Line 2
                      </label>
                      <input
                        type="text"
                        value={formData.hero.headlinePart2}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: { ...formData.hero, headlinePart2: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif text-base"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Hero Sacred Statement / Quote
                      </label>
                      <input
                        type="text"
                        value={formData.hero.quote}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, quote: e.target.value } })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif italic"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Hero Supporting Description Paragraph
                      </label>
                      <textarea
                        rows={3}
                        value={formData.hero.description}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, description: e.target.value } })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none leading-relaxed"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: SCRIPTURE & STORY */}
            {activeTab === 'scripture_story' && (
              <div className="space-y-6">
                {/* Scripture Interlude */}
                <div className="space-y-4 border-b border-[#171916]/15 pb-6">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    Scripture Interlude (Green Section)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Section Header Label
                      </label>
                      <input
                        type="text"
                        value={formData.scripture.label}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            scripture: { ...formData.scripture, label: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Scripture Citation
                      </label>
                      <input
                        type="text"
                        value={formData.scripture.citation}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            scripture: { ...formData.scripture, citation: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Central Scripture Verse / Text
                      </label>
                      <textarea
                        rows={2}
                        value={formData.scripture.quote}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            scripture: { ...formData.scripture, quote: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* Church Heritage & Story */}
                <div className="space-y-4">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    Church Heritage & Landscape Story
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Story Chapter Label
                      </label>
                      <input
                        type="text"
                        value={formData.story.chapter}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, chapter: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Story Main Title
                      </label>
                      <input
                        type="text"
                        value={formData.story.title}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, title: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif font-bold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Story Subtitle
                      </label>
                      <input
                        type="text"
                        value={formData.story.subtitle}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, subtitle: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Essay Paragraph 1
                      </label>
                      <textarea
                        rows={3}
                        value={formData.story.essayParagraph1}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, essayParagraph1: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none leading-relaxed"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Essay Paragraph 2
                      </label>
                      <textarea
                        rows={3}
                        value={formData.story.essayParagraph2}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, essayParagraph2: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none leading-relaxed"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Pull Quote
                      </label>
                      <input
                        type="text"
                        value={formData.story.pullQuote}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            story: { ...formData.story, pullQuote: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif italic"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: PASTOR PROFILE */}
            {activeTab === 'pastor' && (
              <div className="space-y-6">
                <div className="border-b border-[#171916]/15 pb-2">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    Pastor Sarah Waweru Editorial Profile
                  </h4>
                  <p className="font-sans text-xs text-[#171916]/70">
                    Edit pastoral biography, welcome message, and office counseling hours.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Pastor Name
                    </label>
                    <input
                      type="text"
                      value={formData.pastor.name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, name: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif font-bold text-base"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Role / Subtitle
                    </label>
                    <input
                      type="text"
                      value={formData.pastor.subtitle}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, subtitle: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Welcome Heading
                    </label>
                    <input
                      type="text"
                      value={formData.pastor.welcomeHeading}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, welcomeHeading: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif text-base"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Welcome Quote
                    </label>
                    <input
                      type="text"
                      value={formData.pastor.welcomeQuote}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, welcomeQuote: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-serif italic"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Letter / Bio Paragraph 1
                    </label>
                    <textarea
                      rows={3}
                      value={formData.pastor.p1}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, p1: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none leading-relaxed"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Letter / Bio Paragraph 2
                    </label>
                    <textarea
                      rows={3}
                      value={formData.pastor.p2}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, p2: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none leading-relaxed"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Office & Counseling Hours
                    </label>
                    <input
                      type="text"
                      value={formData.pastor.officeHours}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          pastor: { ...formData.pastor, officeHours: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: WEEKLY SERVICES */}
            {activeTab === 'services' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-[#171916]/15 pb-2">
                  <div>
                    <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                      Weekly Service Times & Liturgical Ledger
                    </h4>
                    <p className="font-sans text-xs text-[#171916]/70">
                      Edit service titles, days, times, and descriptions.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddSchedule}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Service</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {formData.schedules.map((schedule, idx) => (
                    <div
                      key={schedule.id}
                      className="p-4 bg-white border border-[#171916]/15 space-y-3 shadow-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-serif italic text-sm font-bold text-[#B66A43]">
                            0{idx + 1}.
                          </span>
                          <input
                            type="text"
                            value={schedule.title}
                            onChange={(e) => handleScheduleChange(idx, 'title', e.target.value)}
                            className="font-serif font-bold text-base text-[#183D32] bg-transparent border-b border-dashed border-[#183D32]/30 focus:outline-none px-1"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveSchedule(schedule.id)}
                          className="text-rose-700 hover:text-rose-950 p-1"
                          title="Remove service"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Day of Week
                          </label>
                          <input
                            type="text"
                            value={schedule.day}
                            onChange={(e) => handleScheduleChange(idx, 'day', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-medium"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Service Time *
                          </label>
                          <input
                            type="text"
                            value={schedule.time}
                            onChange={(e) => handleScheduleChange(idx, 'time', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-semibold text-[#183D32]"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Sanctuary Location
                          </label>
                          <input
                            type="text"
                            value={schedule.location}
                            onChange={(e) => handleScheduleChange(idx, 'location', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                          />
                        </div>

                        <div className="sm:col-span-3">
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Brief Description / Focus
                          </label>
                          <input
                            type="text"
                            value={schedule.description}
                            onChange={(e) => handleScheduleChange(idx, 'description', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: SERMON ARCHIVE */}
            {activeTab === 'sermons' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-[#171916]/15 pb-2">
                  <div>
                    <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                      Sermon Archive & YouTube Media
                    </h4>
                    <p className="font-sans text-xs text-[#171916]/70">
                      Manage featured sermon and video teachings archive.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddSermon}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Sermon</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {(formData.sermons || []).map((sermon, idx) => (
                    <div
                      key={sermon.id}
                      className="p-4 bg-white border border-[#171916]/15 space-y-3 shadow-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-serif text-sm font-bold text-[#B66A43]">
                            {idx === 0 ? '★ Lead Sermon' : `Sermon 0${idx + 1}`}
                          </span>
                          <input
                            type="text"
                            value={sermon.title}
                            onChange={(e) => handleSermonChange(idx, 'title', e.target.value)}
                            className="font-serif font-bold text-base text-[#183D32] bg-transparent border-b border-dashed border-[#183D32]/30 focus:outline-none px-1"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveSermon(sermon.id)}
                          className="text-rose-700 hover:text-rose-950 p-1"
                          title="Remove sermon"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Speaker
                          </label>
                          <input
                            type="text"
                            value={sermon.speaker}
                            onChange={(e) => handleSermonChange(idx, 'speaker', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Scripture Reading
                          </label>
                          <input
                            type="text"
                            value={sermon.scripture}
                            onChange={(e) => handleSermonChange(idx, 'scripture', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none text-[#B66A43] font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            YouTube Video ID (e.g. kJQP7kiw5Fk)
                          </label>
                          <input
                            type="text"
                            value={sermon.youtubeId}
                            onChange={(e) => handleSermonChange(idx, 'youtubeId', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-mono"
                          />
                        </div>

                        <div className="sm:col-span-3">
                          <label className="block text-[11px] font-sans text-[#171916]/70 mb-0.5">
                            Summary & Key Truth
                          </label>
                          <textarea
                            rows={2}
                            value={sermon.summary}
                            onChange={(e) => handleSermonChange(idx, 'summary', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 7: MINISTRIES & EVENTS */}
            {activeTab === 'ministries_events' && (
              <div className="space-y-8">
                {/* Ministries */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-[#171916]/15 pb-2">
                    <span className="font-serif text-xl font-bold text-[#183D32]">
                      Church Ministries & Fellowships
                    </span>
                    <button
                      type="button"
                      onClick={handleAddMinistry}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Ministry</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {(formData.ministries || []).map((min, idx) => (
                      <div
                        key={min.id}
                        className="p-3 bg-white border border-[#171916]/15 space-y-2 shadow-xs"
                      >
                        <div className="flex items-center justify-between">
                          <input
                            type="text"
                            value={min.name}
                            onChange={(e) => handleMinistryChange(idx, 'name', e.target.value)}
                            className="font-serif font-bold text-base text-[#183D32] bg-transparent border-b border-[#183D32]/20 focus:outline-none px-1"
                          />
                          <button
                            type="button"
                            onClick={() => handleRemoveMinistry(min.id)}
                            className="text-rose-700 hover:text-rose-950 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div>
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Ministry Lead</label>
                            <input
                              type="text"
                              value={min.lead}
                              onChange={(e) => handleMinistryChange(idx, 'lead', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Meeting Time</label>
                            <input
                              type="text"
                              value={min.meetingTime}
                              onChange={(e) => handleMinistryChange(idx, 'meetingTime', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Description</label>
                            <textarea
                              rows={2}
                              value={min.description}
                              onChange={(e) => handleMinistryChange(idx, 'description', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Events */}
                <div className="space-y-4 pt-4 border-t border-[#171916]/15">
                  <div className="flex items-center justify-between border-b border-[#171916]/15 pb-2">
                    <span className="font-serif text-xl font-bold text-[#183D32]">
                      Upcoming Calendar & Seasonal Events
                    </span>
                    <button
                      type="button"
                      onClick={handleAddEvent}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#183D32] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#B66A43]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Event</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {(formData.events || []).map((ev, idx) => (
                      <div
                        key={ev.id}
                        className="p-3 bg-white border border-[#171916]/15 space-y-2 shadow-xs"
                      >
                        <div className="flex items-center justify-between">
                          <input
                            type="text"
                            value={ev.title}
                            onChange={(e) => handleEventChange(idx, 'title', e.target.value)}
                            className="font-serif font-bold text-base text-[#183D32] bg-transparent border-b border-[#183D32]/20 focus:outline-none px-1"
                          />
                          <button
                            type="button"
                            onClick={() => handleRemoveEvent(ev.id)}
                            className="text-rose-700 hover:text-rose-950 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                          <div>
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Date</label>
                            <input
                              type="text"
                              value={ev.date}
                              onChange={(e) => handleEventChange(idx, 'date', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Time</label>
                            <input
                              type="text"
                              value={ev.time}
                              onChange={(e) => handleEventChange(idx, 'time', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-[#171916]/60 block">Tag / Category</label>
                            <input
                              type="text"
                              value={ev.tag}
                              onChange={(e) => handleEventChange(idx, 'tag', e.target.value)}
                              className="w-full px-2 py-1 bg-stone-50 border border-[#171916]/15"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 8: M-PESA GIVING & CONTACTS */}
            {activeTab === 'giving' && (
              <div className="space-y-6">
                <div className="border-b border-[#171916]/15 pb-2">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    M-Pesa Stewardship & Pastoral Contacts
                  </h4>
                  <p className="font-sans text-xs text-[#171916]/70">
                    Update payment credentials and hotlines synced to Firestore.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Giving Channel Type
                    </label>
                    <select
                      value={formData.mpesa.type}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, type: e.target.value as 'paybill' | 'till' },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 font-sans focus:border-[#183D32] focus:outline-none"
                    >
                      <option value="paybill">Paybill Number</option>
                      <option value="till">Buy Goods Till Number</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      M-Pesa Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.mpesa.number}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, number: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 font-mono font-bold text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Account Name / Suffix
                    </label>
                    <input
                      type="text"
                      value={formData.mpesa.accountName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, accountName: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Registered Business Name
                    </label>
                    <input
                      type="text"
                      value={formData.mpesa.businessName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, businessName: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Pastor Phone Number
                    </label>
                    <input
                      type="text"
                      value={formData.mpesa.pastorContactPhone}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, pastorContactPhone: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      WhatsApp Number (International, without +)
                    </label>
                    <input
                      type="text"
                      value={formData.mpesa.whatsappNumber}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, whatsappNumber: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                      Church Email Address
                    </label>
                    <input
                      type="email"
                      value={formData.mpesa.email}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          mpesa: { ...formData.mpesa, email: e.target.value },
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 9: DIRECTIONS & FOOTER */}
            {activeTab === 'directions_footer' && (
              <div className="space-y-6">
                <div className="border-b border-[#171916]/15 pb-2">
                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#183D32]">
                    Location Directions & Footer Content
                  </h4>
                  <p className="font-sans text-xs text-[#171916]/70">
                    Edit transit directions, arrival advice, and editorial footer texts.
                  </p>
                </div>

                <div className="space-y-4">
                  <span className="font-serif text-lg font-bold text-[#183D32] block">
                    Location & Travel Coordinates
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Sanctuary Physical Address
                      </label>
                      <input
                        type="text"
                        value={formData.directions.addressTitle}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            directions: { ...formData.directions, addressTitle: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Landmarks & County
                      </label>
                      <input
                        type="text"
                        value={formData.directions.addressDetails}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            directions: { ...formData.directions, addressDetails: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Driving Directions from Nyeri / Nairobi
                      </label>
                      <textarea
                        rows={2}
                        value={formData.directions.drivingDirections}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            directions: { ...formData.directions, drivingDirections: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Public Matatu & Boda Boda Guide
                      </label>
                      <textarea
                        rows={2}
                        value={formData.directions.matatuDirections}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            directions: { ...formData.directions, matatuDirections: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-[#171916]/15">
                  <span className="font-serif text-lg font-bold text-[#183D32] block">
                    Footer Editorial Texts
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Footer Summary Paragraph
                      </label>
                      <textarea
                        rows={2}
                        value={formData.footer.summary}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            footer: { ...formData.footer, summary: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Doctrinal Motto / Slogan
                      </label>
                      <input
                        type="text"
                        value={formData.footer.motto}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            footer: { ...formData.footer, motto: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                        Grand Bottom Watermark Headline
                      </label>
                      <input
                        type="text"
                        value={formData.footer.grandHeadline}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            footer: { ...formData.footer, grandHeadline: e.target.value },
                          })
                        }
                        className="w-full px-3 py-2 text-xs bg-white border border-[#171916]/20 uppercase"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Actions Bar */}
            <div className="pt-6 border-t border-[#171916]/15 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sticky bottom-0 bg-[#F3EFE6] py-3">
              <button
                type="button"
                onClick={() => {
                  onResetSettings();
                  onClose();
                }}
                className="px-4 py-2.5 text-xs font-sans text-rose-800 hover:text-rose-950 flex items-center justify-center gap-1.5 transition-colors"
                title="Restore default church configuration"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset to Church Defaults</span>
              </button>

              <div className="flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-sans text-[#171916]/70 hover:text-[#171916]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-6 py-2.5 bg-[#183D32] text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#B66A43] transition-colors flex items-center justify-center gap-2 disabled:opacity-75 shadow-sm"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving to Firebase...</span>
                    </>
                  ) : (
                    <>
                      <Cloud className="w-3.5 h-3.5" />
                      <span>Save All Changes to Firebase</span>
                    </>
                  )}
                </button>
              </div>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
