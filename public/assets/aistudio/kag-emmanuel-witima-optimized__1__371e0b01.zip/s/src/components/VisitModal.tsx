import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, Heart, CheckCircle2, MessageCircle } from 'lucide-react';
import { ChurchSettings } from '../types/church';

interface VisitModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ChurchSettings;
}

export const VisitModal: React.FC<VisitModalProps> = ({
  isOpen,
  onClose,
  settings,
}) => {
  const [visitorName, setVisitorName] = useState('');
  const [visitorPhone, setVisitorPhone] = useState('');
  const [visitDate, setVisitDate] = useState('This Coming Sunday');
  const [guestsCount, setGuestsCount] = useState('1 (Just Me)');
  const [needsTransportInfo, setNeedsTransportInfo] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmed(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-[#F3EFE6] text-[#171916] border border-[#171916]/20 p-6 sm:p-10 shadow-2xl overflow-y-auto max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#171916]/10 pb-4 mb-6">
          <div>
            <span className="font-sans text-[10px] uppercase tracking-[0.3em] text-[#B66A43] font-bold block">
              You Are Warmly Expected · Witima
            </span>
            <h3 className="font-serif text-3xl font-normal text-[#171916] mt-1">
              Plan Your Sunday Visit
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#171916]/60 hover:text-[#183D32] transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmed ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-none bg-[#183D32] text-[#F3EFE6] flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-[#B69A62]" />
            </div>
            <h4 className="font-serif text-2xl font-bold text-[#183D32]">
              We Look Forward to Welcoming You!
            </h4>
            <p className="font-sans text-sm text-[#171916]/80 max-w-md mx-auto leading-relaxed">
              Dear {visitorName || 'Friend'}, our church hospitality team and Pastor Sarah Waweru will be honored to welcome you this Sunday at 10:00 AM.
            </p>
            <div className="p-4 bg-[#183D32]/5 border border-[#183D32]/15 text-xs font-sans text-[#183D32] space-y-1">
              <div><strong>Sanctuary:</strong> KAG Emmanuel Church, Witima Market Centre, Othaya</div>
              <div><strong>Celebration Service:</strong> Sunday at 10:00 AM</div>
            </div>
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={`https://wa.me/${settings.mpesa.whatsappNumber}?text=Hello%20Pastor%20Sarah,%20my%20name%20is%20${encodeURIComponent(visitorName || 'a visitor')}%20and%20I%20am%20visiting%20KAG%20Emmanuel%20Church%20Witima%20this%20Sunday!`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-5 py-2.5 bg-[#183D32] text-[#F3EFE6] font-sans text-xs uppercase tracking-wider font-semibold hover:bg-[#171916] flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Say Hello on WhatsApp</span>
              </a>
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 border border-[#171916]/20 font-sans text-xs uppercase tracking-wider font-medium text-[#171916]"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Quick Sanctuary Orientation */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-white/70 border border-[#171916]/10 text-xs font-sans">
              <div>
                <span className="font-bold text-[#183D32] block mb-0.5">Service Time</span>
                Sunday 10:00 AM – 12:45 PM
              </div>
              <div>
                <span className="font-bold text-[#183D32] block mb-0.5">Atmosphere</span>
                Warm, Spirit-filled, Family
              </div>
              <div>
                <span className="font-bold text-[#183D32] block mb-0.5">Attire & Weather</span>
                Come as you are · Highland breeze
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={visitorName}
                    onChange={(e) => setVisitorName(e.target.value)}
                    placeholder="e.g. David Mwangi"
                    className="w-full px-3 py-2 text-sm bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                    Phone Number (for greeting)
                  </label>
                  <input
                    type="tel"
                    value={visitorPhone}
                    onChange={(e) => setVisitorPhone(e.target.value)}
                    placeholder="07XX XXX XXX"
                    className="w-full px-3 py-2 text-sm bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                    When are you planning to visit?
                  </label>
                  <select
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-sans"
                  >
                    <option value="This Coming Sunday">This Coming Sunday</option>
                    <option value="Next Sunday">Next Sunday</option>
                    <option value="Mid-week Fellowship">Wednesday Mid-week Service</option>
                    <option value="Monthly Kesha">Monthly Friday Night Kesha</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-sans font-semibold text-[#171916]/80 mb-1">
                    Are you coming with family or guests?
                  </label>
                  <select
                    value={guestsCount}
                    onChange={(e) => setGuestsCount(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#171916]/20 focus:border-[#183D32] focus:outline-none font-sans"
                  >
                    <option value="1 (Just Me)">1 (Just Me)</option>
                    <option value="2 People">2 People</option>
                    <option value="Family with Children">Family with Children (3-5)</option>
                    <option value="Group of 6+">Group of 6+</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="transportCheck"
                  checked={needsTransportInfo}
                  onChange={(e) => setNeedsTransportInfo(e.target.checked)}
                  className="rounded-none border-[#171916]/30 text-[#183D32] focus:ring-0"
                />
                <label htmlFor="transportCheck" className="text-xs font-sans text-[#171916]/80">
                  I would appreciate a phone call with directions from Othaya town.
                </label>
              </div>

              <div className="pt-4 border-t border-[#171916]/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-sans text-[#171916]/70 hover:text-[#171916]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#183D32] text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#171916] transition-colors"
                >
                  Confirm My Visit
                </button>
              </div>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};
