import React from 'react';
import { MapPin, Navigation, Car, Bus, MessageCircle, ExternalLink, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface VisitDirectionsProps {
  settings: ChurchSettings;
  onOpenVisitModal: () => void;
}

export const VisitDirections: React.FC<VisitDirectionsProps> = ({
  settings,
  onOpenVisitModal,
}) => {
  const directions = settings.directions || {
    chapter: 'Chapter 09 · Pilgrim’s Way',
    title: 'Journey to',
    subtitle: 'Witima Sanctuary',
    addressTitle: 'KAG Emmanuel Church Witima',
    addressDetails: 'Witima Market Centre, Off Othaya-Chinga Road, Othaya, Nyeri County, Kenya',
    drivingDirections: 'From Nairobi, take the Thika Superhighway through Sagana into Othaya town. From Othaya round-about, take the Chinga tarmac road westward for approximately 6.5 km to Witima Centre. On-site parking available.',
    matatuDirections: 'Board any Othaya-bound shuttle (2NK, 4NTE, Naniki). At Othaya terminal, board a local matatu heading to Witima / Chinga and alight at Witima Market Stage. Church ushers will assist you.',
    arrivalAdvice: '9:30 AM for warm fellowship and prayer before the 10:00 AM celebration.',
    mapsQuery: 'Witima, Othaya, Nyeri, Kenya',
  };

  return (
    <section id="location" className="relative w-full bg-[#183D32] text-[#F3EFE6] py-16 sm:py-20 lg:py-24 overflow-hidden border-b border-[#F3EFE6]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Curatorial Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 border-b border-[#F3EFE6]/15 pb-5 mb-12 sm:mb-16"
        >
          <div>
            <span className="font-sans text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#B69A62] font-semibold block mb-2">
              {directions.chapter}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F3EFE6] tracking-tight">
              {directions.title} <br />
              <span className="italic text-[#B69A62]">{directions.subtitle}</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#F3EFE6]/80 max-w-sm tracking-wide">
            Whether arriving from Nairobi, Nyeri, or neighboring highland ridges, our gates and welcome team are ready to receive you.
          </p>
        </motion.div>

        {/* 2-Column Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Column 1: Travel Guidelines */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 space-y-6 flex flex-col justify-between"
          >
            <div className="space-y-5">
              <div className="flex items-start gap-3.5">
                <MapPin className="w-5 h-5 text-[#B69A62] shrink-0 mt-1" />
                <div>
                  <span className="text-[10px] uppercase font-sans tracking-[0.25em] text-[#B69A62] font-bold block mb-1">
                    PHYSICAL SANCTUARY ADDRESS
                  </span>
                  <div className="font-serif text-xl sm:text-2xl font-medium text-white">
                    {directions.addressTitle}
                  </div>
                  <p className="font-sans text-xs text-[#F3EFE6]/80 mt-1">
                    {directions.addressDetails}
                  </p>
                </div>
              </div>

              {/* Transit Directions Breakdown */}
              <div className="space-y-4 pt-3 border-t border-[#F3EFE6]/10">
                <div className="flex gap-3 items-start">
                  <Car className="w-4 h-4 text-[#B66A43] shrink-0 mt-1" />
                  <div>
                    <span className="font-serif text-base sm:text-lg text-white font-semibold block">
                      By Private Vehicle
                    </span>
                    <p className="font-sans text-xs text-[#F3EFE6]/80 leading-relaxed mt-0.5">
                      {directions.drivingDirections}
                    </p>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <Bus className="w-4 h-4 text-[#B66A43] shrink-0 mt-1" />
                  <div>
                    <span className="font-serif text-base sm:text-lg text-white font-semibold block">
                      By Public Transport (Matatu)
                    </span>
                    <p className="font-sans text-xs text-[#F3EFE6]/80 leading-relaxed mt-0.5">
                      {directions.matatuDirections}
                    </p>
                  </div>
                </div>
              </div>

              {/* Timing reminder */}
              <div className="p-3.5 bg-[#171916]/50 border border-[#F3EFE6]/10 flex items-center gap-3">
                <Clock className="w-4 h-4 text-[#B69A62] shrink-0" />
                <div className="text-xs font-sans text-[#F3EFE6]/90">
                  <strong className="text-white">Recommended Sunday Arrival:</strong> {directions.arrivalAdvice}
                </div>
              </div>
            </div>

            {/* Actions: Full width on mobile */}
            <div className="pt-4 border-t border-[#F3EFE6]/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(directions.mapsQuery || 'Witima, Othaya, Nyeri, Kenya')}`}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-3.5 bg-[#B69A62] text-[#171916] font-sans text-xs uppercase tracking-widest font-bold hover:bg-white transition-colors flex items-center justify-center gap-2 text-center"
              >
                <Navigation className="w-4 h-4" />
                <span>Open Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href={`https://wa.me/${settings.mpesa.whatsappNumber}?text=Praise%20God%20Welcome%20Team,%20I%20am%20planning%20to%20visit%20KAG%20Emmanuel%20Church%20Witima%20this%20Sunday.`}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-3.5 border border-[#F3EFE6]/20 text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-medium hover:border-[#B69A62] hover:text-[#B69A62] transition-colors flex items-center justify-center gap-2 text-center"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Message Welcome Team</span>
              </a>
            </div>
          </motion.div>

          {/* Column 2: Embedded Google Map */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col"
          >
            <div className="relative w-full h-72 sm:h-80 lg:h-full min-h-[300px] sm:min-h-[360px] bg-[#171916] border border-[#F3EFE6]/15 overflow-hidden shadow-md">
              <iframe
                title="KAG Emmanuel Church Witima Location Map"
                src="https://maps.google.com/maps?q=Witima%20Othaya%20Nyeri%20Kenya&t=&z=13&ie=UTF8&iwloc=&output=embed"
                className="w-full h-full border-0 filter contrast-[1.03]"
                loading="lazy"
              />
              
              <div className="absolute top-3 left-3 bg-[#171916]/90 px-3 py-1 border border-[#F3EFE6]/20 text-[9px] sm:text-[10px] uppercase font-sans tracking-widest text-[#B69A62] font-semibold">
                CENTRAL HIGHLANDS SANCTUARY · NYERI
              </div>
            </div>

            <div className="mt-2.5 flex items-center justify-between text-[11px] font-sans text-[#F3EFE6]/50">
              <span>{directions.addressTitle}</span>
              <span>Elevation: 1,840m ASL</span>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
};
