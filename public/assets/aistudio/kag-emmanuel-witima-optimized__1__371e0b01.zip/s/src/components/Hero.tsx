import React from 'react';
import { ArrowDown, MapPin, Clock, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { ChurchSettings } from '../types/church';

interface HeroProps {
  settings: ChurchSettings;
  onOpenVisitModal: () => void;
  onOpenPrayerModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  settings,
  onOpenVisitModal,
  onOpenPrayerModal,
}) => {
  const hero = settings.hero || {
    label: 'Sanctuary · Central Highlands',
    headlinePart1: 'KAG Emmanuel',
    headlinePart2: 'Church Witima',
    quote: 'A HOME FOR FAITH. A PEOPLE OF PURPOSE.',
    description: 'KAG (Kenya Assemblies of God) Emmanuel Church Witima, led by Senior Pastor Sarah Waweru, gathers in Witima, Othaya, Nyeri County, Kenya for spirit-filled Pentecostal worship, sound biblical doctrine, and genuine community fellowship.',
    ctaPrimary: 'Plan Your Sunday Visit',
    ctaSecondary: 'Submit Prayer Altar',
    imageSrc: '/images/hero_worship_witima.webp',
  };

  return (
    <section className="relative w-full bg-[#F3EFE6] text-[#171916] overflow-hidden border-b border-[#171916]/10">
      
      {/* Hero Composition with Controlled Typographic Scale & Asymmetrical Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-16 lg:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Editorial Headline & Manifesto */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col space-y-6 sm:space-y-7"
          >
            {/* Small Uppercase Editorial Label */}
            <div className="inline-flex items-center gap-2">
              <span className="w-6 h-px bg-[#B66A43]" />
              <span className="text-[10px] sm:text-xs font-sans uppercase tracking-[0.25em] text-[#B66A43] font-semibold">
                {hero.label}
              </span>
            </div>

            {/* Controlled Main Heading: 44–54px on mobile via clamp */}
            <h1 className="font-serif text-[clamp(2.65rem,6vw,4.5rem)] font-normal tracking-tight text-[#171916] leading-[1.02] sm:leading-[0.98]">
              {hero.headlinePart1}
              <br />
              {hero.headlinePart2}
            </h1>

            {/* Supporting Statement & Description */}
            <div className="space-y-3 pt-1">
              <blockquote className="font-serif text-xl sm:text-2xl text-[#183D32] leading-snug tracking-tight">
                “{hero.quote}”
              </blockquote>
              <p className="font-sans text-sm sm:text-base text-[#171916]/80 leading-relaxed max-w-lg">
                {hero.description}
              </p>
            </div>

            {/* Responsive Actions */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={onOpenVisitModal}
                className="w-full sm:w-auto px-6 py-3.5 bg-[#183D32] text-[#F3EFE6] font-sans text-xs uppercase tracking-widest font-semibold hover:bg-[#171916] transition-all flex items-center justify-center gap-2 group text-center shadow-sm"
              >
                <span>{hero.ctaPrimary}</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>

              <button
                onClick={onOpenPrayerModal}
                className="w-full sm:w-auto px-5 py-3.5 border border-[#171916]/25 text-[#171916] font-sans text-xs uppercase tracking-widest font-medium hover:border-[#183D32] hover:text-[#183D32] transition-colors text-center"
              >
                {hero.ctaSecondary}
              </button>
            </div>

            {/* Subtle Invitation to Discover */}
            <div className="pt-2 hidden sm:flex items-center gap-3 text-xs font-sans tracking-widest uppercase text-[#171916]/60">
              <a href="#about" className="flex items-center gap-2 hover:text-[#183D32] transition-colors group">
                <span className="p-1.5 border border-[#171916]/20 rounded-none group-hover:border-[#183D32] transition-colors">
                  <ArrowDown className="w-3.5 h-3.5" />
                </span>
                <span>Discover The Sanctuary Story</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Prominent Worship Photography with Controlled Aspect Ratio */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 w-full"
          >
            {/* Image Container */}
            <div className="relative aspect-[16/11] sm:aspect-[4/3] w-full overflow-hidden bg-[#183D32]/10 shadow-lg border border-[#171916]/10">
              <img fetchPriority="high" decoding="async"
                src={hero.imageSrc}
                alt="Worship service at KAG Emmanuel Church Witima"
                className="w-full h-full object-cover object-center filter saturate-[0.95]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171916]/75 via-transparent to-transparent pointer-events-none" />

              <div className="absolute top-3 left-3 sm:top-4 sm:left-4 bg-[#F3EFE6]/95 px-2.5 py-1 text-[9px] sm:text-[10px] tracking-[0.2em] font-sans uppercase font-bold text-[#183D32]">
                SANCTUARY AT WITIMA
              </div>

              <div className="absolute bottom-3 left-3 right-3 sm:bottom-4 sm:left-4 sm:right-4 text-[#F3EFE6]">
                <div className="flex items-end justify-between border-t border-[#F3EFE6]/30 pt-2">
                  <span className="font-serif italic text-sm sm:text-base text-[#F3EFE6]">
                    "All the Gospel to all the world"
                  </span>
                  <span className="text-[10px] font-sans uppercase tracking-widest text-[#B69A62] font-semibold">
                    Fig. 01 · Worship
                  </span>
                </div>
              </div>
            </div>

            {/* Service Highlight Strip */}
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3 p-3.5 bg-white/75 border border-[#171916]/10">
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#B66A43] shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="block text-[9px] uppercase font-sans tracking-widest text-[#171916]/60">Divine Service</span>
                  <span className="font-serif text-sm font-bold text-[#183D32]">Sunday 10:00 AM</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#183D32] shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="block text-[9px] uppercase font-sans tracking-widest text-[#171916]/60">Sanctuary</span>
                  <span className="font-sans text-xs font-medium text-[#171916] truncate block">{settings.locationString}</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Calendar className="w-4 h-4 text-[#B69A62] shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="block text-[9px] uppercase font-sans tracking-widest text-[#171916]/60">Senior Pastor</span>
                  <span className="font-serif text-xs font-bold text-[#171916] truncate block">{settings.pastorName}</span>
                </div>
              </div>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
};
