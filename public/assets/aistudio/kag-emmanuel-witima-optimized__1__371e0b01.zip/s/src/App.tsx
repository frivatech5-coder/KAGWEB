import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ScriptureInterlude } from './components/ScriptureInterlude';
import { ChurchStory } from './components/ChurchStory';
import { PastorProfile } from './components/PastorProfile';
import { ServicesPrograms } from './components/ServicesPrograms';
import { SermonArchive } from './components/SermonArchive';
import { FellowshipGallery } from './components/FellowshipGallery';
import { MinistriesShowcase } from './components/MinistriesShowcase';
import { UpcomingEvents } from './components/UpcomingEvents';
import { GivingMpesa } from './components/GivingMpesa';
import { VisitDirections } from './components/VisitDirections';
import { Footer } from './components/Footer';
const VisitModal = lazy(() => import('./components/VisitModal').then((m) => ({ default: m.VisitModal })));
const PrayerRequestModal = lazy(() => import('./components/PrayerRequestModal').then((m) => ({ default: m.PrayerRequestModal })));
const AdminEditorModal = lazy(() => import('./components/AdminEditorModal').then((m) => ({ default: m.AdminEditorModal })));
import { initialChurchSettings } from './data/defaultChurchData';
import { ChurchSettings } from './types/church';
const loadFirebase = () => import('./lib/firebase');

export default function App() {
  const [settings, setSettings] = useState<ChurchSettings>(() => {
    try {
      const saved = localStorage.getItem('witima_church_settings');
      if (saved) {
        return JSON.parse(
          saved.replace(/\/src\/assets\/images\/([a-z_]+)_\d+\.jpg/g, '/images/$1.webp')
        );
      }
    } catch {
      // Fallback
    }
    return initialChurchSettings;
  });

  const [visitModalOpen, setVisitModalOpen] = useState(false);
  const [prayerModalOpen, setPrayerModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);

  // Real-time synchronization with Firebase Firestore
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    let cancelled = false;
    // Load Firebase after first paint so it never blocks the initial render
    const start = () => loadFirebase().then(({ testConnection, subscribeToChurchSettings }) => {
    if (cancelled) return;
    testConnection();
    unsubscribe = subscribeToChurchSettings(
      (remoteSettings) => {
        if (remoteSettings && remoteSettings.churchName) {
          remoteSettings = JSON.parse(
            JSON.stringify(remoteSettings).replace(/\/src\/assets\/images\/([a-z_]+)_\d+\.jpg/g, '/images/$1.webp')
          );
          setSettings(remoteSettings);
          try {
            localStorage.setItem('witima_church_settings', JSON.stringify(remoteSettings));
          } catch {
            // Ignore
          }
        }
      },
      (error) => {
        console.warn('Real-time sync error, using local fallback:', error);
      }
    );
    });
    const idle = (window as any).requestIdleCallback as ((cb: () => void) => number) | undefined;
    if (idle) idle(start); else setTimeout(start, 800);

    return () => {
      cancelled = true;
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const handleSaveSettings = async (newSettings: ChurchSettings) => {
    setSettings(newSettings);
    try {
      localStorage.setItem('witima_church_settings', JSON.stringify(newSettings));
    } catch (e) {
      console.error('Could not save church settings to localStorage', e);
    }

    // Save directly to Firebase Firestore
    try {
      await (await loadFirebase()).saveChurchSettingsToFirebase(newSettings);
    } catch (error) {
      console.error('Firebase persistence failed:', error);
      throw error;
    }
  };

  const handleResetSettings = async () => {
    setSettings(initialChurchSettings);
    try {
      localStorage.removeItem('witima_church_settings');
    } catch (e) {
      console.error('Could not reset church settings', e);
    }

    try {
      await (await loadFirebase()).saveChurchSettingsToFirebase(initialChurchSettings);
    } catch (error) {
      console.error('Firebase reset persistence failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-[#F3EFE6] text-[#171916] selection:bg-[#B66A43] selection:text-[#F3EFE6] relative">
      {/* 1. Slim, Sophisticated Top Navigation */}
      <Navbar
        settings={settings}
        onOpenVisitModal={() => setVisitModalOpen(true)}
        onOpenPrayerModal={() => setPrayerModalOpen(true)}
        onOpenAdminModal={() => setAdminModalOpen(true)}
      />

      <main>
        {/* 2. Asymmetrical Editorial Hero (Parish Metadata Row Removed per Request) */}
        <Hero
          settings={settings}
          onOpenVisitModal={() => setVisitModalOpen(true)}
          onOpenPrayerModal={() => setPrayerModalOpen(true)}
        />

        {/* 3. Sacred Scripture Meditation Interlude (Deep Forest Green) */}
        <ScriptureInterlude settings={settings} />

        {/* 4. Heritage & Landscape Story of Witima, Othaya */}
        <ChurchStory settings={settings} />

        {/* 5. Editorial Profile of Senior Pastor Sarah Waweru (Ink Black & Terracotta) */}
        <PastorProfile
          settings={settings}
          onOpenPrayerModal={() => setPrayerModalOpen(true)}
        />

        {/* 6. The Sacred Rhythm: Weekly Programs Ledger with Editable Times */}
        <ServicesPrograms
          settings={settings}
          onOpenAdminModal={() => setAdminModalOpen(true)}
          onOpenVisitModal={() => setVisitModalOpen(true)}
        />

        {/* 7. The Living Word: Sermon Archive with YouTube Video Player */}
        <SermonArchive settings={settings} />

        {/* 8. Fellowship & Visual Community Gallery */}
        <FellowshipGallery settings={settings} />

        {/* 9. Church Ministries: Women of Purpose, Men, Youth Ablaze, Children, Compassion */}
        <MinistriesShowcase
          settings={settings}
          onOpenVisitModal={() => setVisitModalOpen(true)}
        />

        {/* 10. Seasonal Calendar & Upcoming Gatherings */}
        <UpcomingEvents settings={settings} />

        {/* 11. Sacred Stewardship: Safaricom M-Pesa Giving with Editable Codes */}
        <GivingMpesa
          settings={settings}
          onOpenAdminModal={() => setAdminModalOpen(true)}
        />

        {/* 12. Pilgrim's Way: Directions to Witima & Google Maps Integration */}
        <VisitDirections
          settings={settings}
          onOpenVisitModal={() => setVisitModalOpen(true)}
        />
      </main>

      {/* 13. Oversized Grand Editorial Footer */}
      <Footer
        settings={settings}
        onOpenVisitModal={() => setVisitModalOpen(true)}
        onOpenPrayerModal={() => setPrayerModalOpen(true)}
        onOpenAdminModal={() => setAdminModalOpen(true)}
      />

      {/* Interactive Modals (lazy loaded) */}
      <Suspense fallback={null}>
      <VisitModal
        isOpen={visitModalOpen}
        onClose={() => setVisitModalOpen(false)}
        settings={settings}
      />

      <PrayerRequestModal
        isOpen={prayerModalOpen}
        onClose={() => setPrayerModalOpen(false)}
        settings={settings}
      />

      <AdminEditorModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onResetSettings={handleResetSettings}
      />
      </Suspense>
    </div>
  );
}
