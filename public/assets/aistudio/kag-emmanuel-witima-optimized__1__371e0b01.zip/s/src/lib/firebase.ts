import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  onSnapshot,
  collection,
  addDoc,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { ChurchSettings } from '../types/church';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'settings', 'witima_config'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or initializing.');
    }
  }
}

// Real-time synchronization for Church Settings
const SETTINGS_DOC_PATH = 'settings';
const SETTINGS_DOC_ID = 'witima_config';

export function subscribeToChurchSettings(
  onUpdate: (settings: ChurchSettings) => void,
  onError?: (error: Error) => void
) {
  const settingsDocRef = doc(db, SETTINGS_DOC_PATH, SETTINGS_DOC_ID);
  
  return onSnapshot(
    settingsDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as ChurchSettings;
        onUpdate(data);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, `${SETTINGS_DOC_PATH}/${SETTINGS_DOC_ID}`);
      if (onError) onError(error);
    }
  );
}

// Save Church Settings to Firebase
export async function saveChurchSettingsToFirebase(settings: ChurchSettings): Promise<void> {
  const path = `${SETTINGS_DOC_PATH}/${SETTINGS_DOC_ID}`;
  try {
    const settingsDocRef = doc(db, SETTINGS_DOC_PATH, SETTINGS_DOC_ID);
    await setDoc(settingsDocRef, {
      ...settings,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Submit Prayer Petition to Firebase
export async function submitPrayerPetitionToFirebase(petition: {
  name: string;
  contact: string;
  category: string;
  requestText: string;
  isConfidential: boolean;
}): Promise<void> {
  const path = 'prayer_petitions';
  try {
    const colRef = collection(db, path);
    await addDoc(colRef, {
      ...petition,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
